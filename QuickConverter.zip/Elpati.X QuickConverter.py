# -*- coding: utf-8 -*-
"""
QuickConventer
FFmpeg tabanlı video/ses/fotoğraf dönüştürücü — TR/EN tam çevirili
Ayarlar kalıcı: %APPDATA%/QuickConventer/settings.json (Windows)
"""
import os, re, json, shutil, subprocess, sys, threading, time, tkinter as tk
import urllib.request, zipfile, tempfile, platform
from tkinter import filedialog, messagebox, ttk

APP_NAME = "QuickConventer"
SETTINGS_FOLDER_NAME = "QuickConventer"
MIRRORS = [
    "https://www.gyan.dev/ffmpeg/builds/ffmpeg-release-essentials.zip",
    "https://github.com/BtbN/FFmpeg-Builds/releases/download/latest/ffmpeg-master-latest-win64-gpl.zip",
]
D = {"bg":"#1e1e1e","bg2":"#252526","bg3":"#2d2d30","fg":"#e0e0e0","fgd":"#a0a0a0",
     "acc":"#0e639c","acch":"#1177bb","bor":"#3e3e42","ebg":"#3c3c3c","sel":"#094771",
     "ok":"#4ec9b0","blue":"#3a9bd9","green":"#3fbf3f"}

# ============================================================
#  ÇÖZÜNÜRLÜK
# ============================================================
RES_MAP = {
    "Orijinal":None, "Original":None,
    "7680x4320 (8K)":"4320","3840x2160 (4K)":"2160","2560x1440 (1440p)":"1440",
    "1920x1080 (1080p)":"1080","1280x720 (720p)":"720","854x480 (480p)":"480",
    "640x360 (360p)":"360","426x240 (240p)":"240","320x180 (180p)":"180",
    "256x144 (144p)":"144","160x120 (160p)":"160","160x90 (90p)":"90",
    "128x72 (72p)":"72","96x54 (54p)":"54","64x36 (36p)":"36",
    "48x27 (27p)":"27","32x18 (18p)":"18","16x9 (16p)":"16",
    "16x16 (16p kare)":"16", "16x16 (16p square)":"16",
    "8x8 (8p)":"8","4x4 (4p)":"4","2x2 (2p)":"2","1x1 (1p)":"1",
}
RES_TR = ["Orijinal","7680x4320 (8K)","3840x2160 (4K)","2560x1440 (1440p)",
          "1920x1080 (1080p)","1280x720 (720p)","854x480 (480p)","640x360 (360p)",
          "426x240 (240p)","320x180 (180p)","256x144 (144p)","160x120 (160p)",
          "160x90 (90p)","128x72 (72p)","96x54 (54p)","64x36 (36p)",
          "48x27 (27p)","32x18 (18p)","16x9 (16p)","16x16 (16p kare)",
          "8x8 (8p)","4x4 (4p)","2x2 (2p)","1x1 (1p)"]
RES_EN = ["Original","7680x4320 (8K)","3840x2160 (4K)","2560x1440 (1440p)",
          "1920x1080 (1080p)","1280x720 (720p)","854x480 (480p)","640x360 (360p)",
          "426x240 (240p)","320x180 (180p)","256x144 (144p)","160x120 (160p)",
          "160x90 (90p)","128x72 (72p)","96x54 (54p)","64x36 (36p)",
          "48x27 (27p)","32x18 (18p)","16x9 (16p)","16x16 (16p square)",
          "8x8 (8p)","4x4 (4p)","2x2 (2p)","1x1 (1p)"]

# ============================================================
#  CODEC'LER
# ============================================================
CODECS = [
    {"id":"libx264",   "v_codec":"libx264",   "min_h":2,   "preset":True,  "crf":True},
    {"id":"libx265",   "v_codec":"libx265",   "min_h":2,   "preset":True,  "crf":True},
    {"id":"h264_nvenc","v_codec":"h264_nvenc","min_h":144, "preset":False, "hw":"nvenc"},
    {"id":"hevc_nvenc","v_codec":"hevc_nvenc","min_h":144, "preset":False, "hw":"nvenc"},
    {"id":"h264_qsv",  "v_codec":"h264_qsv",  "min_h":144, "preset":False, "hw":"qsv"},
    {"id":"hevc_qsv",  "v_codec":"hevc_qsv",  "min_h":144, "preset":False, "hw":"qsv"},
    {"id":"h264_amf",  "v_codec":"h264_amf",  "min_h":144, "preset":False, "hw":"amf"},
    {"id":"hevc_amf",  "v_codec":"hevc_amf",  "min_h":144, "preset":False, "hw":"amf"},
    {"id":"libvpx",    "v_codec":"libvpx",    "min_h":2,   "preset":True,  "crf":True},
    {"id":"libvpx-vp9","v_codec":"libvpx-vp9","min_h":2,   "preset":True,  "crf":True},
    {"id":"libaom-av1","v_codec":"libaom-av1","min_h":2,   "preset":True,  "crf":True},
    {"id":"libsvtav1", "v_codec":"libsvtav1", "min_h":2,   "preset":True,  "crf":True},
    {"id":"librav1e",  "v_codec":"librav1e",  "min_h":2,   "preset":True,  "crf":True},
    {"id":"mpeg4",     "v_codec":"mpeg4",     "min_h":1,   "preset":False, "qscale":True},
    {"id":"mpeg2video","v_codec":"mpeg2video","min_h":16,  "preset":False, "qscale":True},
    {"id":"mpeg1video","v_codec":"mpeg1video","min_h":16,  "preset":False, "qscale":True},
    {"id":"h263",      "v_codec":"h263",      "min_h":16,  "preset":False, "qscale":True},
    {"id":"h263p",     "v_codec":"h263p",     "min_h":16,  "preset":False, "qscale":True},
    {"id":"libtheora", "v_codec":"libtheora", "min_h":16,  "preset":False, "crf":True},
    {"id":"wmv2",      "v_codec":"wmv2",      "min_h":16,  "preset":False, "qscale":True},
    {"id":"wmv1",      "v_codec":"wmv1",      "min_h":16,  "preset":False, "qscale":True},
    {"id":"msmpeg4v2", "v_codec":"msmpeg4v2", "min_h":16,  "preset":False, "qscale":True},
    {"id":"msmpeg4v3", "v_codec":"msmpeg4v3", "min_h":16,  "preset":False, "qscale":True},
    {"id":"prores_hq", "v_codec":"prores_ks", "min_h":144, "preset":False, "prores_hq":True},
    {"id":"prores_422","v_codec":"prores_ks", "min_h":144, "preset":False, "prores_422":True},
    {"id":"dnxhd",     "v_codec":"dnxhd",     "min_h":720, "preset":False, "dnxhd":True},
    {"id":"mjpeg",     "v_codec":"mjpeg",     "min_h":16,  "preset":False, "qscale":True},
    {"id":"ffv1",      "v_codec":"ffv1",      "min_h":16,  "preset":False, "lossless":True},
    {"id":"huffyuv",   "v_codec":"huffyuv",   "min_h":16,  "preset":False, "lossless":True},
]
CODEC_BY_ID = {c["id"]: c for c in CODECS}

CODEC_LABELS = {
"tr": {
    "libx264":"H.264 / AVC (libx264)  [En Uyumlu]",
    "libx265":"H.265 / HEVC (libx265)",
    "h264_nvenc":"H.264 / AVC (NVENC - NVIDIA)",
    "hevc_nvenc":"H.265 / HEVC (NVENC - NVIDIA)",
    "h264_qsv":"H.264 / AVC (QSV - Intel)",
    "hevc_qsv":"H.265 / HEVC (QSV - Intel)",
    "h264_amf":"H.264 / AVC (AMF - AMD)",
    "hevc_amf":"H.265 / HEVC (AMF - AMD)",
    "libvpx":"VP8 (libvpx)", "libvpx-vp9":"VP9 (libvpx-vp9)",
    "libaom-av1":"AV1 (libaom-av1)  [Yavaş]",
    "libsvtav1":"AV1 (libsvtav1)  [Hızlı]",
    "librav1e":"AV1 (librav1e)",
    "mpeg4":"MPEG-4 Part 2 (mpeg4)  [Küçük boyutlar]",
    "mpeg2video":"MPEG-2 (mpeg2video)",
    "mpeg1video":"MPEG-1 (mpeg1video)",
    "h263":"H.263 (h263)", "h263p":"H.263+ (h263p)",
    "libtheora":"Theora (libtheora)",
    "wmv2":"WMV2 (wmv2)", "wmv1":"WMV1 (wmv1)",
    "msmpeg4v2":"MSMPEG4v2 (msmpeg4v2)",
    "msmpeg4v3":"MSMPEG4v3 (msmpeg4v3)",
    "prores_hq":"ProRes 422 HQ (prores_ks)",
    "prores_422":"ProRes 422 (prores_ks -profil 2)",
    "dnxhd":"DNxHD (dnxhd)", "mjpeg":"MJPEG (mjpeg)",
    "ffv1":"FFV1 (kayıpsız)", "huffyuv":"HuffYUV (kayıpsız)",
},
"en": {
    "libx264":"H.264 / AVC (libx264)  [Most compatible]",
    "libx265":"H.265 / HEVC (libx265)",
    "h264_nvenc":"H.264 / AVC (NVENC - NVIDIA)",
    "hevc_nvenc":"H.265 / HEVC (NVENC - NVIDIA)",
    "h264_qsv":"H.264 / AVC (QSV - Intel)",
    "hevc_qsv":"H.265 / HEVC (QSV - Intel)",
    "h264_amf":"H.264 / AVC (AMF - AMD)",
    "hevc_amf":"H.265 / HEVC (AMF - AMD)",
    "libvpx":"VP8 (libvpx)", "libvpx-vp9":"VP9 (libvpx-vp9)",
    "libaom-av1":"AV1 (libaom-av1)  [Slow]",
    "libsvtav1":"AV1 (libsvtav1)  [Fast]",
    "librav1e":"AV1 (librav1e)",
    "mpeg4":"MPEG-4 Part 2 (mpeg4)  [Small sizes]",
    "mpeg2video":"MPEG-2 (mpeg2video)",
    "mpeg1video":"MPEG-1 (mpeg1video)",
    "h263":"H.263 (h263)", "h263p":"H.263+ (h263p)",
    "libtheora":"Theora (libtheora)",
    "wmv2":"WMV2 (wmv2)", "wmv1":"WMV1 (wmv1)",
    "msmpeg4v2":"MSMPEG4v2 (msmpeg4v2)",
    "msmpeg4v3":"MSMPEG4v3 (msmpeg4v3)",
    "prores_hq":"ProRes 422 HQ (prores_ks)",
    "prores_422":"ProRes 422 (prores_ks -profile 2)",
    "dnxhd":"DNxHD (dnxhd)", "mjpeg":"MJPEG (mjpeg)",
    "ffv1":"FFV1 (lossless)", "huffyuv":"HuffYUV (lossless)",
},
}

# ============================================================
#  CONTAINER'LAR
# ============================================================
CONTAINERS = [
    {"id":"mp4","ext":".mp4"},   {"id":"mkv","ext":".mkv"},
    {"id":"webm","ext":".webm"}, {"id":"mov","ext":".mov"},
    {"id":"avi","ext":".avi"},   {"id":"wmv","ext":".wmv"},
    {"id":"flv","ext":".flv"},   {"id":"mpg","ext":".mpg"},
    {"id":"mpeg","ext":".mpeg"}, {"id":"m4v","ext":".m4v"},
    {"id":"ts","ext":".ts"},     {"id":"m2ts","ext":".m2ts"},
    {"id":"ogv","ext":".ogv"},   {"id":"3gp","ext":".3gp"},
    {"id":"3g2","ext":".3g2"},   {"id":"mxf","ext":".mxf"},
    {"id":"gif","ext":".gif"},   {"id":"apng","ext":".apng"},
    {"id":"y4m","ext":".y4m"},   {"id":"nut","ext":".nut"},
    {"id":"rm","ext":".rm"},     {"id":"asf","ext":".asf"},
    {"id":"dv","ext":".dv"},     {"id":"f4v","ext":".f4v"},
]
CONTAINER_BY_ID = {c["id"]: c for c in CONTAINERS}

CONTAINER_LABELS = {
"tr": {
    "mp4":"MP4  (.mp4)  [En yaygın]",
    "mkv":"Matroska  (.mkv)  [Her şeyi alır]",
    "webm":"WebM  (.webm)  [Web / VP8-VP9-AV1]",
    "mov":"QuickTime  (.mov)  [Apple / ProRes]",
    "avi":"AVI  (.avi)  [Eski / uyumlu]",
    "wmv":"Windows Media  (.wmv)", "flv":"Flash Video  (.flv)",
    "mpg":"MPEG-PS  (.mpg)", "mpeg":"MPEG-PS  (.mpeg)",
    "m4v":"MPEG-4 Video  (.m4v)  [iTunes]",
    "ts":"MPEG-TS  (.ts)  [Yayın]", "m2ts":"Blu-ray TS  (.m2ts)",
    "ogv":"Ogg Video  (.ogv)", "3gp":"3GPP  (.3gp)  [Mobil]",
    "3g2":"3GPP2  (.3g2)", "mxf":"MXF  (.mxf)  [Broadcast / DNxHD]",
    "gif":"Animasyonlu GIF  (.gif)  [Sessiz]",
    "apng":"Animasyonlu PNG  (.apng)  [Sessiz]",
    "y4m":"YUV4MPEG  (.y4m)  [Ham]",
    "nut":"NUT  (.nut)  [FFmpeg kendi]",
    "rm":"RealMedia  (.rm)", "asf":"ASF  (.asf)",
    "dv":"DV  (.dv)", "f4v":"Flash MP4  (.f4v)",
},
"en": {
    "mp4":"MP4  (.mp4)  [Most common]",
    "mkv":"Matroska  (.mkv)  [Accepts everything]",
    "webm":"WebM  (.webm)  [Web / VP8-VP9-AV1]",
    "mov":"QuickTime  (.mov)  [Apple / ProRes]",
    "avi":"AVI  (.avi)  [Legacy / compatible]",
    "wmv":"Windows Media  (.wmv)", "flv":"Flash Video  (.flv)",
    "mpg":"MPEG-PS  (.mpg)", "mpeg":"MPEG-PS  (.mpeg)",
    "m4v":"MPEG-4 Video  (.m4v)  [iTunes]",
    "ts":"MPEG-TS  (.ts)  [Broadcast]", "m2ts":"Blu-ray TS  (.m2ts)",
    "ogv":"Ogg Video  (.ogv)", "3gp":"3GPP  (.3gp)  [Mobile]",
    "3g2":"3GPP2  (.3g2)", "mxf":"MXF  (.mxf)  [Broadcast / DNxHD]",
    "gif":"Animated GIF  (.gif)  [Silent]",
    "apng":"Animated PNG  (.apng)  [Silent]",
    "y4m":"YUV4MPEG  (.y4m)  [Raw]",
    "nut":"NUT  (.nut)  [FFmpeg native]",
    "rm":"RealMedia  (.rm)", "asf":"ASF  (.asf)",
    "dv":"DV  (.dv)", "f4v":"Flash MP4  (.f4v)",
},
}

CONTAINER_AUDIO = {
    ".mp4":"aac",".m4v":"aac",".mov":"aac",".mkv":"aac",
    ".webm":"libopus",".ogv":"libvorbis",".avi":"libmp3lame",
    ".wmv":"wmav2",".asf":"wmav2",".flv":"aac",".f4v":"aac",
    ".mpg":"mp2",".mpeg":"mp2",".ts":"aac",".m2ts":"aac",
    ".3gp":"aac",".3g2":"aac",".mxf":"pcm_s16le",
    ".gif":None,".apng":None,".y4m":None,
    ".nut":"aac",".rm":"ac3",".dv":"pcm_s16le",
}

# ============================================================
#  SES CODEC'LERİ
# ============================================================
AUDIO_CODECS = [
    {"id":"wav16",  "a_codec":"pcm_s16le",         "ext":".wav"},
    {"id":"mp3",    "a_codec":"libmp3lame",        "ext":".mp3"},
    {"id":"flac",   "a_codec":"flac",              "ext":".flac"},
    {"id":"opus",   "a_codec":"libopus",           "ext":".opus"},
    {"id":"amr",    "a_codec":"libopencore_amrnb", "ext":".amr"},
    {"id":"3gpp",   "a_codec":"aac",               "ext":".3gp",  "fmt":"3gp"},
    {"id":"vorbis", "a_codec":"libvorbis",         "ext":".ogg"},
    {"id":"m3u8",   "a_codec":"aac",               "ext":".m3u8", "hls":True},
    {"id":"aac",    "a_codec":"aac",               "ext":".m4a"},
    {"id":"alac",   "a_codec":"alac",              "ext":".m4a"},
    {"id":"ac3",    "a_codec":"ac3",               "ext":".ac3"},
    {"id":"eac3",   "a_codec":"eac3",              "ext":".eac3"},
    {"id":"dts",    "a_codec":"dca",               "ext":".dts"},
    {"id":"wma",    "a_codec":"wmav2",             "ext":".wma"},
    {"id":"mulaw",  "a_codec":"pcm_mulaw",         "ext":".wav"},
    {"id":"alaw",   "a_codec":"pcm_alaw",          "ext":".wav"},
]
AUDIO_BY_ID = {a["id"]: a for a in AUDIO_CODECS}

AUDIO_LABELS = {
"tr": {
    "wav16":"WAV (pcm_s16le)  [Kayıpsız, evrensel]",
    "mp3":"MP3 (libmp3lame)  [En yaygın]",
    "flac":"FLAC (flac)  [Kayıpsız]",
    "opus":"OPUS (libopus)  [En verimli]",
    "amr":"AMR-NB (libopencore_amrnb)  [Mobil]",
    "3gpp":"3GPP Audio (aac)  [Mobil .3gp]",
    "vorbis":"OGG Vorbis (libvorbis)",
    "m3u8":"M3U8 / M3U (HLS)  [Parçalı yayın + playlist]",
    "aac":"AAC (aac)  [Apple / m4a]",
    "alac":"ALAC (alac)  [Apple kayıpsız]",
    "ac3":"AC3 (ac3)", "eac3":"E-AC3 (eac3)", "dts":"DTS (dca)",
    "wma":"WMA v2 (wmav2)",
    "mulaw":"PCM μ-law (pcm_mulaw)", "alaw":"PCM A-law (pcm_alaw)",
},
"en": {
    "wav16":"WAV (pcm_s16le)  [Lossless, universal]",
    "mp3":"MP3 (libmp3lame)  [Most common]",
    "flac":"FLAC (flac)  [Lossless]",
    "opus":"OPUS (libopus)  [Most efficient]",
    "amr":"AMR-NB (libopencore_amrnb)  [Mobile]",
    "3gpp":"3GPP Audio (aac)  [Mobile .3gp]",
    "vorbis":"OGG Vorbis (libvorbis)",
    "m3u8":"M3U8 / M3U (HLS)  [Segmented stream + playlist]",
    "aac":"AAC (aac)  [Apple / m4a]",
    "alac":"ALAC (alac)  [Apple lossless]",
    "ac3":"AC3 (ac3)", "eac3":"E-AC3 (eac3)", "dts":"DTS (dca)",
    "wma":"WMA v2 (wmav2)",
    "mulaw":"PCM μ-law (pcm_mulaw)", "alaw":"PCM A-law (pcm_alaw)",
},
}

LOSSLESS_A_CODECS = {"flac", "pcm_s16le", "pcm_mulaw", "pcm_alaw", "alac"}

# ============================================================
#  FOTOĞRAF FORMATLARI
# ============================================================
IMAGE_FORMATS = [
    {"id":"png",  "ext":".png",  "ffmpeg":"png",      "pillow":"PNG",  "lossy":False},
    {"id":"jpg",  "ext":".jpg",  "ffmpeg":"mjpeg",    "pillow":"JPEG", "lossy":True},
    {"id":"jpeg", "ext":".jpeg", "ffmpeg":"mjpeg",    "pillow":"JPEG", "lossy":True},
    {"id":"webp", "ext":".webp", "ffmpeg":"libwebp",  "pillow":"WEBP", "lossy":True},
    {"id":"bmp",  "ext":".bmp",  "ffmpeg":"bmp",      "pillow":"BMP",  "lossy":False},
    {"id":"tiff", "ext":".tiff", "ffmpeg":"tiff",     "pillow":"TIFF", "lossy":False},
    {"id":"tif",  "ext":".tif",  "ffmpeg":"tiff",     "pillow":"TIFF", "lossy":False},
    {"id":"gif",  "ext":".gif",  "ffmpeg":"gif",      "pillow":"GIF",  "lossy":False},
    {"id":"ico",  "ext":".ico",  "ffmpeg":"ico",      "pillow":"ICO",  "lossy":False},
    {"id":"tga",  "ext":".tga",  "ffmpeg":"targa",    "pillow":"TGA",  "lossy":False},
    {"id":"ppm",  "ext":".ppm",  "ffmpeg":"ppm",      "pillow":"PPM",  "lossy":False},
    {"id":"pgm",  "ext":".pgm",  "ffmpeg":"pgm",      "pillow":"PPM",  "lossy":False},
    {"id":"pbm",  "ext":".pbm",  "ffmpeg":"pbm",      "pillow":"PPM",  "lossy":False},
    {"id":"pcx",  "ext":".pcx",  "ffmpeg":"pcx",      "pillow":"PCX",  "lossy":False},
    {"id":"dds",  "ext":".dds",  "ffmpeg":"dds",      "pillow":"DDS",  "lossy":False},
    {"id":"exr",  "ext":".exr",  "ffmpeg":"exr",      "pillow":"EXR",  "lossy":False},
    {"id":"hdr",  "ext":".hdr",  "ffmpeg":"hdr",      "pillow":"HDR",  "lossy":False},
    {"id":"avif", "ext":".avif", "ffmpeg":"libaom-av1","pillow":None,  "lossy":True},
]
IMAGE_BY_ID = {im["id"]: im for im in IMAGE_FORMATS}

IMAGE_LABELS = {
"tr": {
    "png":"PNG  (.png)  [Şeffaflık destekli]",
    "jpg":"JPG  (.jpg)  [En yaygın, kayıplı]",
    "jpeg":"JPEG  (.jpeg)  [JPG ile aynı]",
    "webp":"WEBP  (.webp)  [Modern, küçük boyut]",
    "bmp":"BMP  (.bmp)  [Sıkıştırmasız]",
    "tiff":"TIFF  (.tiff)  [Profesyonel, kayıpsız]",
    "tif":"TIF  (.tif)  [TIFF ile aynı]",
    "gif":"GIF  (.gif)  [Animasyonlu]",
    "ico":"ICO  (.ico)  [Windows ikon]",
    "tga":"TGA  (.tga)  [Oyun / eski]",
    "ppm":"PPM  (.ppm)  [Portable Pixmap]",
    "pgm":"PGM  (.pgm)  [Gri ton]",
    "pbm":"PBM  (.pbm)  [Siyah-beyaz]",
    "pcx":"PCX  (.pcx)  [Eski Paint]",
    "dds":"DDS  (.dds)  [Oyun dokusu]",
    "exr":"EXR  (.exr)  [HDR / VFX]",
    "hdr":"HDR  (.hdr)  [Yüksek dinamik aralık]",
    "avif":"AVIF  (.avif)  [Modern, çok küçük]",
},
"en": {
    "png":"PNG  (.png)  [Transparency support]",
    "jpg":"JPG  (.jpg)  [Most common, lossy]",
    "jpeg":"JPEG  (.jpeg)  [Same as JPG]",
    "webp":"WEBP  (.webp)  [Modern, small size]",
    "bmp":"BMP  (.bmp)  [Uncompressed]",
    "tiff":"TIFF  (.tiff)  [Professional, lossless]",
    "tif":"TIF  (.tif)  [Same as TIFF]",
    "gif":"GIF  (.gif)  [Animated]",
    "ico":"ICO  (.ico)  [Windows icon]",
    "tga":"TGA  (.tga)  [Game / legacy]",
    "ppm":"PPM  (.ppm)  [Portable Pixmap]",
    "pgm":"PGM  (.pgm)  [Grayscale]",
    "pbm":"PBM  (.pbm)  [Black & white]",
    "pcx":"PCX  (.pcx)  [Legacy Paint]",
    "dds":"DDS  (.dds)  [Game texture]",
    "exr":"EXR  (.exr)  [HDR / VFX]",
    "hdr":"HDR  (.hdr)  [High dynamic range]",
    "avif":"AVIF  (.avif)  [Modern, very small]",
},
}

# Standart input resim uzantıları (FFmpeg ile okunabilir)
IMAGE_INPUT_EXTS = {".png", ".jpg", ".jpeg", ".webp", ".bmp", ".tiff", ".tif", ".gif",
                    ".ico", ".tga", ".ppm", ".pgm", ".pbm", ".pcx", ".dds", ".exr",
                    ".hdr", ".avif", ".jp2", ".j2k", ".jfif", ".jpe"}

# RAW kamera formatları (Pillow+rawpy gerekli)
RAW_INPUT_EXTS = {".raw", ".cr2", ".cr3", ".nef", ".arw", ".dng", ".orf", ".rw2",
                  ".raf", ".pef", ".srw", ".3fr", ".ari", ".bay", ".crw", ".dcr",
                  ".erf", ".fff", ".iiq", ".k25", ".kc2", ".kdc", ".mef", ".mos",
                  ".mrw", ".nrw", ".pxn", ".r3d", ".rwl", ".rwz", ".sr2", ".srf",
                  ".x3f"}

ALL_IMAGE_INPUT_EXTS = IMAGE_INPUT_EXTS | RAW_INPUT_EXTS

# ============================================================
#  UI SÖZLÜĞÜ
# ============================================================
LANG = {
"tr": {
    "tab_conv":"  Dönüştürücü  ","tab_batch":"  Toplu İşlem  ","tab_info":"  Video Bilgisi  ",
    "tab_audio":"  🎵 Ses Dönüştürme  ","tab_image":"  🖼 Fotoğraf Dönüştürme  ",
    "src_frame":" Video Kaynağı ","out_frame":" Çıktı Klasörü ","settings_frame":" Ayarlar ",
    "audio_src_frame":" Ses Dosyası ","audio_settings_frame":" Ses Ayarları ",
    "image_src_frame":" Fotoğraf(lar) ","image_settings_frame":" Fotoğraf Ayarları ",
    "log_frame":" Günlük ","btn_pick":"Seç…","btn_play":"Oynat","btn_convert":"🚀 Dönüştür",
    "btn_audio_convert":"🎵 Dönüştür","btn_image_convert":"🖼 Dönüştür",
    "btn_batch_add":"Ekle…","btn_batch_clr":"Temizle","btn_batch_run":"▶ Başlat",
    "btn_analyze":"FFprobe ile Analiz Et","btn_reset":"↺ Sıfırla",
    "btn_img_add_files":"Dosya Ekle…","btn_img_add_folder":"Klasör Ekle…","btn_img_clear":"Temizle",
    "lbl_encoder":"Kodek:","lbl_preset":"Preset:",
    "lbl_crf":"CRF (0-51):","lbl_res":"Çözünürlük:","lbl_abr":"Bitrate:",
    "lbl_container":"Container:","lbl_acodec":"Ses Codec (ses çıkarma):",
    "lbl_audio_codec":"Ses Formatı:",
    "lbl_img_format":"Hedef Format:","lbl_img_quality":"Kalite (1-100):",
    "chk_audio_only":"Sadece ses çıkar (video yok)",
    "col_file":"Dosya","col_status":"Durum",
    "st_ready":"Hazır.","st_downloading":"FFmpeg indiriliyor...","st_cancelled":"İptal edildi.",
    "st_failed_inst":"Kurulamadı.","st_converting":"Dönüştürülüyor...",
    "st_converting2":"Dönüştürülüyor %{p}","st_done":"Tamamlandı!","st_failed":"Başarısız.",
    "st_selected":"Seçildi: {n}","st_dl_progress":"İndiriliyor %{p} ({m:.1f}/{t:.1f} MB) {s:.1f} MB/s",
    "log_ready":"[Logo] X harfi ikonu yüklendi.","log_ffmpeg_ok":"[OK] FFmpeg: {path}",
    "log_ver":"[OK] Sürüm: {v}","log_ffmpeg_no":"[!] FFmpeg yok, indiriliyor...",
    "log_installed":"[OK] Kuruldu: {path}","log_cancelled":"[!] İptal edildi.",
    "log_sel":"Seçildi: {p}","log_cmd":"Komut: {c}","log_err":"Hata: {e}","log_ok_out":"[OK] {p}",
    "log_extracting":"Arşiv çıkarılıyor...",
    "log_settings_loaded":"[Ayarlar] Kaydedilmiş ayarlar yüklendi.",
    "log_settings_saved":"[Ayarlar] Ayarlar kaydedildi.",
    "log_settings_reset":"[Ayarlar] Varsayılanlara sıfırlandı.",
    "log_settings_path":"[Ayarlar] Konum: {p}",
    "log_img_added":"[+] {n} dosya eklendi.","log_img_folder":"[+] Klasörden {n} resim eklendi.",
    "log_img_installing":"[i] Pillow kuruluyor...","log_img_installed":"[OK] Pillow kuruldu.",
    "log_img_install_fail":"[!] Pillow kurulamadı: {e}",
    "log_img_rawpy_installing":"[i] rawpy kuruluyor (RAW desteği)...",
    "log_img_rawpy_installed":"[OK] rawpy kuruldu.",
    "log_img_rawpy_fail":"[!] rawpy kurulamadı: {e}",
    "dlg_title":"FFmpeg Otomatik Kurulum","dlg_dl":"FFmpeg indiriliyor...",
    "dlg_note":"İlk çalıştırmada bir kez yapılır.","dlg_cancel":"İptal",
    "dlg_cancelling":"İptal ediliyor...","dlg_conn":"Bağlanılıyor...",
    "mb_done_inst":"Tamam","mb_done_txt":"FFmpeg kuruldu!","mb_err_title":"FFmpeg Kurulamadı",
    "mb_err_body":"{msg}\n\nManuel:\n{path}","warn_no_vid":"Önce video seç!",
    "warn_no_src":"Geçerli video seç.","warn_empty":"Liste boş.","err_ffmpeg":"FFmpeg hazır değil.",
    "err_ffprobe":"ffprobe yok.","err_generic":"Hata","info_ok_title":"Başarılı",
    "info_ok_body":"Kaydedildi:\n{p}","info_err_title":"Hata","info_err_body":"Dönüştürme başarısız.",
    "warn_no_audio":"Önce ses dosyası seç!",
    "info_audio_ok_body":"Ses kaydedildi:\n{p}",
    "info_audio_err_body":"Ses dönüştürme başarısız.",
    "warn_no_image":"Önce fotoğraf ekle!",
    "info_image_ok_body":"Fotoğraf(lar) dönüştürüldü:\n{p}",
    "info_image_err_body":"Bazı fotoğraflar dönüştürülemedi.",
    "batch_ok_title":"Bitti","batch_ok_body":"Toplu işlem tamamlandı!","batch_pending":"Bekliyor",
    "batch_run":"İşleniyor...","batch_done":"Tamamlandı ✔","batch_err":"Hata ❌",
    "img_done":"Tamamlandı ✔","img_err":"Hata ❌",
    "lang_label":"Dil:","filetypes_all":"Tümü","filetypes_vid":"Video",
    "filetypes_aud":"Ses","filetypes_img":"Fotoğraf",
    "autofallback":"[!] {codec} {h}p desteklemiyor → MPEG-4'e geçildi.",
    "aud_fallback":"[!] {ext} {ac} desteklemiyor → {nac} kullanıldı.",
    "err_windows_only":"Otomatik indirme sadece Windows'ta destekleniyor.",
    "err_no_exe":"Arşivde ffmpeg.exe bulunamadı.",
    "err_unknown":"Bilinmeyen hata.",
    "err_cancelled":"İptal edildi.",
},
"en": {
    "tab_conv":"  Converter  ","tab_batch":"  Batch  ","tab_info":"  Video Info  ",
    "tab_audio":"  🎵 Audio Converter  ","tab_image":"  🖼 Photo Converter  ",
    "src_frame":" Video Source ","out_frame":" Output Folder ","settings_frame":" Settings ",
    "audio_src_frame":" Audio File ","audio_settings_frame":" Audio Settings ",
    "image_src_frame":" Photo(s) ","image_settings_frame":" Photo Settings ",
    "log_frame":" Log ","btn_pick":"Pick…","btn_play":"Play","btn_convert":"🚀 Convert",
    "btn_audio_convert":"🎵 Convert","btn_image_convert":"🖼 Convert",
    "btn_batch_add":"Add…","btn_batch_clr":"Clear","btn_batch_run":"▶ Start",
    "btn_analyze":"Analyze with FFprobe","btn_reset":"↺ Reset",
    "btn_img_add_files":"Add Files…","btn_img_add_folder":"Add Folder…","btn_img_clear":"Clear",
    "lbl_encoder":"Codec:","lbl_preset":"Preset:",
    "lbl_crf":"CRF (0-51):","lbl_res":"Resolution:","lbl_abr":"Bitrate:",
    "lbl_container":"Container:","lbl_acodec":"Audio Codec (audio-only):",
    "lbl_audio_codec":"Audio Format:",
    "lbl_img_format":"Target Format:","lbl_img_quality":"Quality (1-100):",
    "chk_audio_only":"Extract audio only (no video)",
    "col_file":"File","col_status":"Status",
    "st_ready":"Ready.","st_downloading":"Downloading FFmpeg...","st_cancelled":"Cancelled.",
    "st_failed_inst":"Failed to install.","st_converting":"Converting...",
    "st_converting2":"Converting %{p}","st_done":"Done!","st_failed":"Failed.",
    "st_selected":"Selected: {n}","st_dl_progress":"Downloading %{p} ({m:.1f}/{t:.1f} MB) {s:.1f} MB/s",
    "log_ready":"[Logo] X letter icon loaded.","log_ffmpeg_ok":"[OK] FFmpeg: {path}",
    "log_ver":"[OK] Version: {v}","log_ffmpeg_no":"[!] FFmpeg not found, downloading...",
    "log_installed":"[OK] Installed: {path}","log_cancelled":"[!] Cancelled.",
    "log_sel":"Selected: {p}","log_cmd":"Command: {c}","log_err":"Error: {e}","log_ok_out":"[OK] {p}",
    "log_extracting":"Extracting archive...",
    "log_settings_loaded":"[Settings] Loaded saved settings.",
    "log_settings_saved":"[Settings] Settings saved.",
    "log_settings_reset":"[Settings] Reset to defaults.",
    "log_settings_path":"[Settings] Path: {p}",
    "log_img_added":"[+] Added {n} file(s).","log_img_folder":"[+] Added {n} images from folder.",
    "log_img_installing":"[i] Installing Pillow...","log_img_installed":"[OK] Pillow installed.",
    "log_img_install_fail":"[!] Pillow install failed: {e}",
    "log_img_rawpy_installing":"[i] Installing rawpy (RAW support)...",
    "log_img_rawpy_installed":"[OK] rawpy installed.",
    "log_img_rawpy_fail":"[!] rawpy install failed: {e}",
    "dlg_title":"FFmpeg Auto Install","dlg_dl":"Downloading FFmpeg...",
    "dlg_note":"Only happens on first launch.","dlg_cancel":"Cancel",
    "dlg_cancelling":"Cancelling...","dlg_conn":"Connecting...",
    "mb_done_inst":"Done","mb_done_txt":"FFmpeg installed!","mb_err_title":"FFmpeg Install Failed",
    "mb_err_body":"{msg}\n\nManual:\n{path}","warn_no_vid":"Pick a video first!",
    "warn_no_src":"Pick a valid video.","warn_empty":"List is empty.","err_ffmpeg":"FFmpeg not ready.",
    "err_ffprobe":"ffprobe not found.","err_generic":"Error","info_ok_title":"Success",
    "info_ok_body":"Saved:\n{p}","info_err_title":"Error","info_err_body":"Conversion failed.",
    "warn_no_audio":"Pick an audio file first!",
    "info_audio_ok_body":"Audio saved:\n{p}",
    "info_audio_err_body":"Audio conversion failed.",
    "warn_no_image":"Add photos first!",
    "info_image_ok_body":"Photo(s) converted:\n{p}",
    "info_image_err_body":"Some photos could not be converted.",
    "batch_ok_title":"Done","batch_ok_body":"Batch conversion finished!","batch_pending":"Pending",
    "batch_run":"Processing...","batch_done":"Done ✔","batch_err":"Error ❌",
    "img_done":"Done ✔","img_err":"Error ❌",
    "lang_label":"Language:","filetypes_all":"All","filetypes_vid":"Video",
    "filetypes_aud":"Audio","filetypes_img":"Image",
    "autofallback":"[!] {codec} doesn't support {h}p → switched to MPEG-4.",
    "aud_fallback":"[!] {ext} doesn't support {ac} → using {nac}.",
    "err_windows_only":"Auto-download is only supported on Windows.",
    "err_no_exe":"ffmpeg.exe not found in archive.",
    "err_unknown":"Unknown error.",
    "err_cancelled":"Cancelled.",
},
}

LANG_NAMES = {"tr":"Türkçe","en":"English"}


def tr(key, lang="tr", **kw):
    s = LANG.get(lang, LANG["tr"]).get(key, LANG["tr"].get(key, key))
    if kw:
        try: return s.format(**kw)
        except Exception: return s
    return s


def _res_index(cur):
    if cur in RES_TR: return RES_TR.index(cur)
    if cur in RES_EN: return RES_EN.index(cur)
    return 0


def translate_res(cur, lang):
    idx = _res_index(cur)
    if lang == "tr": return RES_TR, RES_TR[idx]
    return RES_EN, RES_EN[idx]


# ==================== TEMA ====================
def apply_theme(root):
    root.configure(bg=D["bg"])
    s = ttk.Style(root)
    try: s.theme_use("clam")
    except: pass
    s.configure(".", background=D["bg"], foreground=D["fg"],
                fieldbackground=D["ebg"], bordercolor=D["bor"],
                lightcolor=D["bg3"], darkcolor=D["bg"], troughcolor=D["bg3"],
                focuscolor=D["acc"], selectbackground=D["sel"],
                selectforeground=D["fg"], font=("Segoe UI", 9))
    s.configure("TFrame", background=D["bg"])
    s.configure("TLabel", background=D["bg"], foreground=D["fg"])
    s.configure("TLabelframe", background=D["bg"], bordercolor=D["bor"])
    s.configure("TLabelframe.Label", background=D["bg"], foreground=D["acch"],
                font=("Segoe UI", 9, "bold"))
    s.configure("TButton", background=D["bg3"], foreground=D["fg"], bordercolor=D["bor"])
    s.map("TButton", background=[("active", D["acc"]), ("pressed", D["acch"])])
    s.configure("TEntry", fieldbackground=D["ebg"], foreground=D["fg"], insertcolor=D["fg"])
    s.configure("TCombobox", fieldbackground=D["ebg"], foreground=D["fg"],
                background=D["bg3"], arrowcolor=D["fg"])
    s.map("TCombobox", fieldbackground=[("readonly", D["ebg"])],
          foreground=[("readonly", D["fg"])])
    root.option_add("*TCombobox*Listbox.background", D["ebg"])
    root.option_add("*TCombobox*Listbox.foreground", D["fg"])
    root.option_add("*TCombobox*Listbox.selectBackground", D["sel"])
    root.option_add("*TCombobox*Listbox.selectForeground", D["fg"])
    s.configure("TSpinbox", fieldbackground=D["ebg"], foreground=D["fg"],
                background=D["bg3"], arrowcolor=D["fg"])
    s.configure("TCheckbutton", background=D["bg"], foreground=D["fg"],
                indicatorcolor=D["bg3"], focuscolor=D["acc"])
    s.map("TCheckbutton", background=[("active", D["bg"])],
          foreground=[("active", D["acch"])])
    s.configure("TNotebook", background=D["bg"], bordercolor=D["bor"])
    s.configure("TNotebook.Tab", background=D["bg3"], foreground=D["fgd"],
                padding=(14, 6), bordercolor=D["bor"])
    s.map("TNotebook.Tab", background=[("selected", D["bg"])],
          foreground=[("selected", D["acch"])])
    s.configure("Treeview", background=D["bg2"], foreground=D["fg"],
                fieldbackground=D["bg2"], bordercolor=D["bor"])
    s.map("Treeview", background=[("selected", D["sel"])],
          foreground=[("selected", "#fff")])
    s.configure("Treeview.Heading", background=D["bg3"], foreground=D["fg"])
    s.map("Treeview.Heading", background=[("active", D["acc"])])
    s.configure("Horizontal.TProgressbar", background=D["acc"],
                troughcolor=D["bg3"], bordercolor=D["bor"],
                lightcolor=D["acc"], darkcolor=D["acc"])
    s.configure("TScrollbar", background=D["bg3"], troughcolor=D["bg"],
                bordercolor=D["bor"], arrowcolor=D["fg"])


# ==================== X LOGO ====================
def make_x_letter(size=64, color=None, bg=None):
    color = color or D["blue"]; bg = bg or D["bg2"]
    img = tk.PhotoImage(width=size, height=size)
    img.put(bg, to=(0, 0, size, size))
    m = max(2, size // 7); t = max(2, size // 7); half = t // 2
    def put(x, y):
        if 0 <= x < size and 0 <= y < size:
            img.put(color, to=(x, y, x + 1, y + 1))
    steps = size - 2 * m
    for i in range(steps + 1):
        x = m + i; y1 = m + i; y2 = (size - 1 - m) - i
        for dx in range(-half, half + 1):
            for dy in range(-half, half + 1):
                put(x + dx, y1 + dy); put(x + dx, y2 + dy)
    return img


def set_icon(win, size=64):
    try:
        img = make_x_letter(size)
        win._ref = img
        win.iconphoto(True, img)
    except Exception: pass


# ==================== YARDIMCILAR ====================
def base_dir():
    if getattr(sys, "frozen", False):
        return os.path.dirname(sys.executable)
    return os.path.dirname(os.path.abspath(__file__))


def settings_dir():
    if os.name == "nt":
        base = os.environ.get("APPDATA") or os.path.expanduser("~")
        return os.path.join(base, SETTINGS_FOLDER_NAME)
    if sys.platform == "darwin":
        return os.path.expanduser(f"~/Library/Application Support/{SETTINGS_FOLDER_NAME}")
    base = os.environ.get("XDG_CONFIG_HOME") or os.path.expanduser("~/.config")
    return os.path.join(base, SETTINGS_FOLDER_NAME)


def settings_path():
    return os.path.join(settings_dir(), "settings.json")


DEFAULT_SETTINGS = {
    "lang":"tr",
    "codec_id":"libx264",
    "container_id":"mp4",
    "audio_codec_id":"aac",
    "audio_only":False,
    "preset":"veryfast",
    "crf":"23",
    "resolution_tr":"Orijinal",
    "audio_br":"128k",
    "output_dir":"",
    "a_codec_id":"mp3",
    "a_br":"192k",
    "a_output_dir":"",
    "img_format_id":"jpg",
    "img_quality":"90",
    "img_output_dir":"",
}


def load_settings():
    p = settings_path()
    if not os.path.isfile(p):
        return dict(DEFAULT_SETTINGS)
    try:
        with open(p, "r", encoding="utf-8") as f:
            data = json.load(f)
        out = dict(DEFAULT_SETTINGS)
        out.update({k: v for k, v in data.items() if k in DEFAULT_SETTINGS})
        return out
    except Exception:
        return dict(DEFAULT_SETTINGS)


def save_settings(data):
    try:
        d = settings_dir()
        os.makedirs(d, exist_ok=True)
        p = os.path.join(d, "settings.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)
        return True
    except Exception as e:
        print("Settings save error:", e)
        return False


def find_tool(name):
    exe = name + (".exe" if os.name == "nt" else "")
    local = os.path.join(base_dir(), "bin", exe)
    if os.path.isfile(local): return local
    return shutil.which(name)


def ffmpeg_ver(path):
    if not path: return None
    try:
        r = subprocess.run([path, "-version"], capture_output=True, text=True, timeout=5)
        if r.returncode == 0:
            m = re.search(r"ffmpeg version (\S+)", r.stdout)
            return m.group(1) if m else "?"
    except Exception: pass
    return None


def has_pillow():
    try:
        import PIL
        return True
    except ImportError:
        return False


def has_rawpy():
    try:
        import rawpy
        return True
    except ImportError:
        return False


def _pip_install(pkg, log_fn):
    if getattr(sys, "frozen", False):
        log_fn("[!] Frozen build — cannot pip install " + pkg)
        return False
    try:
        log_fn(f"[i] pip install {pkg} ...")
        r = subprocess.run([sys.executable, "-m", "pip", "install", "--quiet", pkg],
                           capture_output=True, text=True, timeout=300)
        if r.returncode == 0:
            log_fn(f"[OK] {pkg} kuruldu.")
            return True
        log_fn(f"[!] {pkg} hatası: " + ((r.stderr or r.stdout or "?")[-400:]))
        return False
    except Exception as e:
        log_fn(f"[!] {pkg} hatası: {e}")
        return False


class Cancelled(Exception): pass


def download_ffmpeg(log=print, progress=None, cancel_event=None, log_extracting="Extracting...",
                    msg_windows_only="Auto-download only on Windows.",
                    msg_no_exe="no exe in archive",
                    msg_unknown="unknown error",
                    msg_cancelled="cancelled"):
    if os.name != "nt":
        return False, msg_windows_only
    bin_dir = os.path.join(base_dir(), "bin")
    os.makedirs(bin_dir, exist_ok=True)
    last = None
    for i, url in enumerate(MIRRORS, 1):
        if cancel_event and cancel_event.is_set(): return False, msg_cancelled
        try:
            log(f"[{i}/{len(MIRRORS)}] {url}")
            req = urllib.request.Request(url, headers={"User-Agent":"QuickConventer/1.0"})
            with urllib.request.urlopen(req, timeout=30) as resp:
                total = int(resp.headers.get("Content-Length", 0))
                t0 = time.time(); lastp = 0; tmp_path = None
                with tempfile.NamedTemporaryFile(delete=False, suffix=".zip") as tmp:
                    tmp_path = tmp.name
                    while True:
                        if cancel_event and cancel_event.is_set(): raise Cancelled()
                        buf = resp.read(128*1024)
                        if not buf: break
                        tmp.write(buf)
                        dl = tmp.tell(); now = time.time()
                        if progress and now - lastp > 0.2:
                            lastp = now
                            if total:
                                pct = int(dl*100/total)
                                spd = (dl/1048576)/max(now-t0,0.01)
                                progress(pct, dl/1048576, total/1048576, spd)
            log(log_extracting)
            ok = False
            with zipfile.ZipFile(tmp_path, "r") as z:
                for m in z.namelist():
                    if cancel_event and cancel_event.is_set(): raise Cancelled()
                    fn = os.path.basename(m)
                    if fn in ("ffmpeg.exe", "ffprobe.exe"):
                        with z.open(m) as s, open(os.path.join(bin_dir, fn), "wb") as d:
                            shutil.copyfileobj(s, d)
                        ok = True
            try: os.remove(tmp_path)
            except: pass
            if ok and os.path.isfile(os.path.join(bin_dir, "ffmpeg.exe")):
                return True, bin_dir
            last = msg_no_exe
        except Cancelled:
            return False, msg_cancelled
        except Exception as e:
            last = str(e); log(f"Error: {e}")
    return False, last or msg_unknown


# ==================== İNDİRME PENCERESİ ====================
class DlDialog(tk.Toplevel):
    def __init__(self, master, cancel_event, lang="tr", on_cancel=None):
        super().__init__(master)
        self.lang = lang
        self.title(tr("dlg_title", lang))
        self.geometry("500x220"); self.resizable(False, False)
        self.configure(bg=D["bg"]); self.transient(master); self.grab_set()
        self.protocol("WM_DELETE_WINDOW", self._cancel)
        self.cancel_event = cancel_event; self.on_cancel = on_cancel
        self._done = False
        set_icon(self, 48)
        tk.Label(self, text=tr("dlg_dl", lang), bg=D["bg"], fg=D["fg"],
                 font=("Segoe UI", 12, "bold")).pack(pady=(18, 4))
        tk.Label(self, text=tr("dlg_note", lang), bg=D["bg"], fg=D["fgd"]).pack()
        self.bar = ttk.Progressbar(self, length=440, mode="determinate")
        self.bar.pack(pady=16)
        self.info = tk.Label(self, text=tr("dlg_conn", lang), bg=D["bg"],
                             fg=D["ok"], font=("Consolas", 9))
        self.info.pack()
        self.btn = ttk.Button(self, text=tr("dlg_cancel", lang), command=self._cancel)
        self.btn.pack(pady=12)

    def update_progress(self, pct, mb, tot, spd):
        self.bar.configure(value=pct)
        t = f"{tot:.1f} MB" if tot else "?"
        self.info.configure(text=f"%{pct}  •  {mb:.1f}/{t}  •  {spd:.1f} MB/s")

    def _cancel(self):
        if self._done: return
        self.cancel_event.set()
        self.btn.configure(state="disabled", text=tr("dlg_cancelling", self.lang))
        if self.on_cancel: self.on_cancel()

    def close_safe(self):
        self._done = True
        try: self.grab_release()
        except: pass
        self.destroy()


# ==================== UYGULAMA ====================
class App:
    def __init__(self, root):
        self.root = root
        root.title(APP_NAME); root.geometry("980x780"); root.minsize(840, 700)
        apply_theme(root)
        set_icon(root, 64)

        self.settings = load_settings()

        self.lang = tk.StringVar(value=self.settings["lang"])
        self.input_path = tk.StringVar()
        default_out = self.settings.get("output_dir") or (
            os.path.expanduser("~\\Desktop") if os.name == "nt"
            else os.path.expanduser("~/Desktop"))
        self.output_dir = tk.StringVar(value=default_out)

        # Video
        self.codec_id = self.settings["codec_id"]
        self.container_id = self.settings["container_id"]
        self.audio_codec_id = self.settings["audio_codec_id"]
        self.codec_display = tk.StringVar()
        self.container_display = tk.StringVar()
        self.audio_codec_display = tk.StringVar()
        self.audio_only = tk.BooleanVar(value=self.settings["audio_only"])
        self.preset = tk.StringVar(value=self.settings["preset"])
        self.crf = tk.StringVar(value=self.settings["crf"])
        self.resolution = tk.StringVar(value=self.settings["resolution_tr"])
        self.audio_br = tk.StringVar(value=self.settings["audio_br"])
        self.status = tk.StringVar(value="")

        # Ses
        self.a_input_path = tk.StringVar()
        a_default_out = self.settings.get("a_output_dir") or default_out
        self.a_output_dir = tk.StringVar(value=a_default_out)
        self.a_codec_id = self.settings.get("a_codec_id", "mp3")
        self.a_codec_display = tk.StringVar()
        self.a_br = tk.StringVar(value=self.settings.get("a_br", "192k"))
        self.is_a_converting = False

        # Fotoğraf
        img_default_out = self.settings.get("img_output_dir") or default_out
        self.img_output_dir = tk.StringVar(value=img_default_out)
        self.img_format_id = self.settings.get("img_format_id", "jpg")
        self.img_format_display = tk.StringVar()
        self.img_quality = tk.StringVar(value=self.settings.get("img_quality", "90"))
        self.img_files = []
        self.is_img_converting = False

        self.ffmpeg = find_tool("ffmpeg")
        self.ffprobe = find_tool("ffprobe")
        self.is_converting = False
        self._cancel_event = threading.Event()
        self._dl = None
        self._save_job = None

        self._ui()

        for var in (self.lang, self.preset, self.crf, self.resolution, self.audio_br,
                    self.audio_only, self.output_dir, self.a_br, self.a_output_dir,
                    self.img_quality, self.img_output_dir):
            var.trace_add("write", lambda *a: self._schedule_save())

        self.lang.trace_add("write", lambda *a: self._on_lang_change())
        self._on_lang_change()
        self.root.after(200, self._check)

    def L(self, key, **kw):
        return tr(key, self.lang.get(), **kw)

    def _collect_settings(self):
        cur_res = self.resolution.get()
        idx = _res_index(cur_res)
        res_tr = RES_TR[idx]
        return {
            "lang": self.lang.get(),
            "codec_id": self.codec_id,
            "container_id": self.container_id,
            "audio_codec_id": self.audio_codec_id,
            "audio_only": self.audio_only.get(),
            "preset": self.preset.get(),
            "crf": self.crf.get(),
            "resolution_tr": res_tr,
            "audio_br": self.audio_br.get(),
            "output_dir": self.output_dir.get(),
            "a_codec_id": self.a_codec_id,
            "a_br": self.a_br.get(),
            "a_output_dir": self.a_output_dir.get(),
            "img_format_id": self.img_format_id,
            "img_quality": self.img_quality.get(),
            "img_output_dir": self.img_output_dir.get(),
        }

    def _schedule_save(self):
        if self._save_job:
            try: self.root.after_cancel(self._save_job)
            except: pass
        self._save_job = self.root.after(400, self._do_save)

    def _do_save(self):
        self._save_job = None
        save_settings(self._collect_settings())

    # ========================================================
    #  UI
    # ========================================================
    def _ui(self):
        header = tk.Frame(self.root, bg=D["bg"])
        header.pack(fill="x", padx=10, pady=(8, 0))
        try:
            small = make_x_letter(28); header._small_logo = small
            tk.Label(header, image=small, bg=D["bg"]).pack(side="left", padx=(0, 8))
        except Exception: pass
        tk.Label(header, text=APP_NAME, bg=D["bg"], fg=D["blue"],
                 font=("Segoe UI", 12, "bold")).pack(side="left")

        self.lang_frame = tk.Frame(header, bg=D["bg"])
        self.lang_frame.pack(side="right")
        self.btn_reset = ttk.Button(self.lang_frame, text="↺", command=self._reset_settings)
        self.btn_reset.pack(side="left", padx=(0, 8))
        self.lbl_lang = tk.Label(self.lang_frame, text="Dil:", bg=D["bg"], fg=D["fg"])
        self.lbl_lang.pack(side="left", padx=(0, 4))
        self.lang_display = tk.StringVar()
        self.lang_codes = list(LANG_NAMES.keys())
        self.lang_labels = [f"{LANG_NAMES[c]} ({c})" for c in self.lang_codes]
        self.lang_combo = ttk.Combobox(self.lang_frame, textvariable=self.lang_display,
                                       state="readonly", width=16, values=self.lang_labels)
        self.lang_combo.pack(side="left")
        self.lang_combo.bind("<<ComboboxSelected>>", self._on_lang_combo)

        self.nb = ttk.Notebook(self.root)
        self.nb.pack(fill="both", expand=True, padx=10, pady=10)

        # ---------- Sekme 1: Video Dönüştürücü ----------
        self.t1 = ttk.Frame(self.nb, padding=10); self.nb.add(self.t1, text="")
        self.f_src = ttk.LabelFrame(self.t1, text="", padding=10); self.f_src.pack(fill="x", pady=(0, 8))
        ttk.Entry(self.f_src, textvariable=self.input_path).pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.btn_pick = ttk.Button(self.f_src, text="", command=self.pick_file); self.btn_pick.pack(side="left", padx=2)
        self.btn_play = ttk.Button(self.f_src, text="", command=self.play); self.btn_play.pack(side="left", padx=2)

        self.f_out = ttk.LabelFrame(self.t1, text="", padding=10); self.f_out.pack(fill="x", pady=(0, 8))
        ttk.Entry(self.f_out, textvariable=self.output_dir).pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.btn_out = ttk.Button(self.f_out, text="", command=self.pick_out); self.btn_out.pack(side="left")

        self.f_set = ttk.LabelFrame(self.t1, text="", padding=10); self.f_set.pack(fill="x", pady=(0, 8))

        self.lbl_enc = ttk.Label(self.f_set, text=""); self.lbl_enc.grid(row=0, column=0, sticky="w", pady=3)
        self.cmb_enc = ttk.Combobox(self.f_set, textvariable=self.codec_display, state="readonly", width=52)
        self.cmb_enc.grid(row=0, column=1, sticky="w", padx=8, columnspan=2)
        self.cmb_enc.bind("<<ComboboxSelected>>", self._on_codec_selected)

        self.lbl_cont = ttk.Label(self.f_set, text=""); self.lbl_cont.grid(row=1, column=0, sticky="w", pady=3)
        self.cmb_cont = ttk.Combobox(self.f_set, textvariable=self.container_display, state="readonly", width=52)
        self.cmb_cont.grid(row=1, column=1, sticky="w", padx=8, columnspan=2)
        self.cmb_cont.bind("<<ComboboxSelected>>", self._on_container_selected)

        self.lbl_pre = ttk.Label(self.f_set, text=""); self.lbl_pre.grid(row=2, column=0, sticky="w", pady=3)
        self.cmb_pre = ttk.Combobox(self.f_set, textvariable=self.preset, state="readonly", width=15,
                                    values=["ultrafast","superfast","veryfast","faster","fast","medium","slow"])
        self.cmb_pre.grid(row=2, column=1, sticky="w", padx=8)

        self.lbl_crf = ttk.Label(self.f_set, text=""); self.lbl_crf.grid(row=3, column=0, sticky="w", pady=3)
        self.spn_crf = ttk.Spinbox(self.f_set, from_=0, to=51, textvariable=self.crf, width=6,
                                   command=self._schedule_save)
        self.spn_crf.grid(row=3, column=1, sticky="w", padx=8)
        self.spn_crf.bind("<FocusOut>", lambda e: self._schedule_save())

        self.lbl_res = ttk.Label(self.f_set, text=""); self.lbl_res.grid(row=4, column=0, sticky="w", pady=3)
        self.cmb_res = ttk.Combobox(self.f_set, textvariable=self.resolution, state="readonly",
                                    width=24, values=RES_TR)
        self.cmb_res.grid(row=4, column=1, sticky="w", padx=8)
        self.cmb_res.bind("<<ComboboxSelected>>", lambda e: self._schedule_save())

        self.lbl_abr = ttk.Label(self.f_set, text=""); self.lbl_abr.grid(row=5, column=0, sticky="w", pady=3)
        self.cmb_abr = ttk.Combobox(self.f_set, textvariable=self.audio_br, state="readonly", width=12,
                                    values=["32k","48k","64k","96k","128k","192k","256k","320k"])
        self.cmb_abr.grid(row=5, column=1, sticky="w", padx=8)
        self.cmb_abr.bind("<<ComboboxSelected>>", lambda e: self._schedule_save())

        self.chk_ao = ttk.Checkbutton(self.f_set, text="", variable=self.audio_only,
                                      command=self._on_audio_only_toggle)
        self.chk_ao.grid(row=6, column=0, columnspan=3, sticky="w", pady=(6, 0))

        self.lbl_ac = ttk.Label(self.f_set, text=""); self.lbl_ac.grid(row=7, column=0, sticky="w", pady=3)
        self.cmb_ac = ttk.Combobox(self.f_set, textvariable=self.audio_codec_display, state="readonly", width=52)
        self.cmb_ac.grid(row=7, column=1, sticky="w", padx=8, columnspan=2)
        self.cmb_ac.bind("<<ComboboxSelected>>", self._on_audiocodec_selected)

        af = ttk.Frame(self.t1); af.pack(fill="x", pady=6)
        self.btn_conv = ttk.Button(af, text="", command=self.start); self.btn_conv.pack(side="left", padx=(0, 8))
        self.pb = ttk.Progressbar(af, mode="determinate", length=350); self.pb.pack(side="left", fill="x", expand=True, padx=4)
        self.pl = ttk.Label(af, text="%0"); self.pl.pack(side="left")

        self.log_frame = ttk.LabelFrame(self.t1, text="", padding=6); self.log_frame.pack(fill="both", expand=True)
        self.log = tk.Text(self.log_frame, height=10, wrap="word", state="disabled",
                           bg=D["bg2"], fg=D["ok"], insertbackground=D["fg"],
                           relief="flat", borderwidth=0, font=("Consolas", 9))
        self.log.pack(side="left", fill="both", expand=True)
        sb = ttk.Scrollbar(self.log_frame, command=self.log.yview); sb.pack(side="right", fill="y")
        self.log.configure(yscrollcommand=sb.set)

        # ---------- Sekme 2: Toplu İşlem ----------
        self.t2 = ttk.Frame(self.nb, padding=10); self.nb.add(self.t2, text="")
        bf = ttk.Frame(self.t2); bf.pack(fill="x", pady=(0, 8))
        self.btn_badd = ttk.Button(bf, text="", command=self.batch_add); self.btn_badd.pack(side="left", padx=2)
        self.btn_bclr = ttk.Button(bf, text="", command=self.batch_clear); self.btn_bclr.pack(side="left", padx=2)
        self.btn_brun = ttk.Button(bf, text="", command=self.batch_start); self.btn_brun.pack(side="right")
        self.tree = ttk.Treeview(self.t2, columns=("p","s"), show="headings", height=14)
        self.tree.heading("p", text=""); self.tree.heading("s", text="")
        self.tree.column("p", width=550); self.tree.column("s", width=150)
        self.tree.pack(fill="both", expand=True)

        # ---------- Sekme 3: Video Bilgisi ----------
        self.t3 = ttk.Frame(self.nb, padding=10); self.nb.add(self.t3, text="")
        self.btn_an = ttk.Button(self.t3, text="", command=self.info); self.btn_an.pack(anchor="w", pady=(0, 8))
        self.itxt = tk.Text(self.t3, wrap="word", bg=D["bg2"], fg=D["fg"],
                            insertbackground=D["fg"], relief="flat",
                            borderwidth=0, font=("Consolas", 10))
        self.itxt.pack(fill="both", expand=True)

        # ---------- Sekme 4: Ses Dönüştürme ----------
        self.t4 = ttk.Frame(self.nb, padding=10); self.nb.add(self.t4, text="")

        self.f_asrc = ttk.LabelFrame(self.t4, text="", padding=10)
        self.f_asrc.pack(fill="x", pady=(0, 8))
        ttk.Entry(self.f_asrc, textvariable=self.a_input_path).pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.btn_apick = ttk.Button(self.f_asrc, text="", command=self.a_pick_file)
        self.btn_apick.pack(side="left", padx=2)
        self.btn_aplay = ttk.Button(self.f_asrc, text="", command=self.a_play)
        self.btn_aplay.pack(side="left", padx=2)

        self.f_aout = ttk.LabelFrame(self.t4, text="", padding=10)
        self.f_aout.pack(fill="x", pady=(0, 8))
        ttk.Entry(self.f_aout, textvariable=self.a_output_dir).pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.btn_aout = ttk.Button(self.f_aout, text="", command=self.a_pick_out)
        self.btn_aout.pack(side="left")

        self.f_aset = ttk.LabelFrame(self.t4, text="", padding=10)
        self.f_aset.pack(fill="x", pady=(0, 8))

        self.lbl_acodec = ttk.Label(self.f_aset, text="")
        self.lbl_acodec.grid(row=0, column=0, sticky="w", pady=3)
        self.cmb_acodec = ttk.Combobox(self.f_aset, textvariable=self.a_codec_display,
                                       state="readonly", width=52)
        self.cmb_acodec.grid(row=0, column=1, sticky="w", padx=8, columnspan=2)
        self.cmb_acodec.bind("<<ComboboxSelected>>", self._on_a_codec_selected)

        self.lbl_abrate = ttk.Label(self.f_aset, text="")
        self.lbl_abrate.grid(row=1, column=0, sticky="w", pady=3)
        self.cmb_abrate = ttk.Combobox(self.f_aset, textvariable=self.a_br, state="readonly", width=12,
                                       values=["32k","48k","64k","96k","128k","192k","256k","320k"])
        self.cmb_abrate.grid(row=1, column=1, sticky="w", padx=8)
        self.cmb_abrate.bind("<<ComboboxSelected>>", lambda e: self._schedule_save())

        af2 = ttk.Frame(self.t4); af2.pack(fill="x", pady=6)
        self.btn_aconv = ttk.Button(af2, text="", command=self.start_audio)
        self.btn_aconv.pack(side="left", padx=(0, 8))
        self.a_pb = ttk.Progressbar(af2, mode="determinate", length=350)
        self.a_pb.pack(side="left", fill="x", expand=True, padx=4)
        self.a_pl = ttk.Label(af2, text="%0"); self.a_pl.pack(side="left")

        self.a_log_frame = ttk.LabelFrame(self.t4, text="", padding=6)
        self.a_log_frame.pack(fill="both", expand=True)
        self.a_log = tk.Text(self.a_log_frame, height=10, wrap="word", state="disabled",
                             bg=D["bg2"], fg=D["ok"], insertbackground=D["fg"],
                             relief="flat", borderwidth=0, font=("Consolas", 9))
        self.a_log.pack(side="left", fill="both", expand=True)
        sb2 = ttk.Scrollbar(self.a_log_frame, command=self.a_log.yview); sb2.pack(side="right", fill="y")
        self.a_log.configure(yscrollcommand=sb2.set)

        # ---------- Sekme 5: Fotoğraf Dönüştürme ----------
        self.t5 = ttk.Frame(self.nb, padding=10); self.nb.add(self.t5, text="")

        self.f_imgsrc = ttk.LabelFrame(self.t5, text="", padding=10)
        self.f_imgsrc.pack(fill="x", pady=(0, 8))

        ib = ttk.Frame(self.f_imgsrc); ib.pack(fill="x", pady=(0, 6))
        self.btn_imgadd = ttk.Button(ib, text="", command=self.img_add_files)
        self.btn_imgadd.pack(side="left", padx=2)
        self.btn_imgaddf = ttk.Button(ib, text="", command=self.img_add_folder)
        self.btn_imgaddf.pack(side="left", padx=2)
        self.btn_imgclr = ttk.Button(ib, text="", command=self.img_clear)
        self.btn_imgclr.pack(side="left", padx=2)

        self.img_tree = ttk.Treeview(self.f_imgsrc, columns=("f","s"), show="headings", height=6)
        self.img_tree.heading("f", text=""); self.img_tree.heading("s", text="")
        self.img_tree.column("f", width=600); self.img_tree.column("s", width=120)
        self.img_tree.pack(fill="x")

        self.f_imgout = ttk.LabelFrame(self.t5, text="", padding=10)
        self.f_imgout.pack(fill="x", pady=(0, 8))
        ttk.Entry(self.f_imgout, textvariable=self.img_output_dir).pack(side="left", fill="x", expand=True, padx=(0, 6))
        self.btn_imgout = ttk.Button(self.f_imgout, text="", command=self.img_pick_out)
        self.btn_imgout.pack(side="left")

        self.f_imgset = ttk.LabelFrame(self.t5, text="", padding=10)
        self.f_imgset.pack(fill="x", pady=(0, 8))

        self.lbl_imgfmt = ttk.Label(self.f_imgset, text="")
        self.lbl_imgfmt.grid(row=0, column=0, sticky="w", pady=3)
        self.cmb_imgfmt = ttk.Combobox(self.f_imgset, textvariable=self.img_format_display,
                                       state="readonly", width=48)
        self.cmb_imgfmt.grid(row=0, column=1, sticky="w", padx=8, columnspan=2)
        self.cmb_imgfmt.bind("<<ComboboxSelected>>", self._on_img_format_selected)

        self.lbl_imgq = ttk.Label(self.f_imgset, text="")
        self.lbl_imgq.grid(row=1, column=0, sticky="w", pady=3)
        self.spn_imgq = ttk.Spinbox(self.f_imgset, from_=1, to=100, textvariable=self.img_quality,
                                    width=8, command=self._schedule_save)
        self.spn_imgq.grid(row=1, column=1, sticky="w", padx=8)
        self.spn_imgq.bind("<FocusOut>", lambda e: self._schedule_save())

        af3 = ttk.Frame(self.t5); af3.pack(fill="x", pady=6)
        self.btn_iconv = ttk.Button(af3, text="", command=self.start_image)
        self.btn_iconv.pack(side="left", padx=(0, 8))
        self.i_pb = ttk.Progressbar(af3, mode="determinate", length=350)
        self.i_pb.pack(side="left", fill="x", expand=True, padx=4)
        self.i_pl = ttk.Label(af3, text="%0"); self.i_pl.pack(side="left")

        self.i_log_frame = ttk.LabelFrame(self.t5, text="", padding=6)
        self.i_log_frame.pack(fill="both", expand=True)
        self.i_log = tk.Text(self.i_log_frame, height=8, wrap="word", state="disabled",
                             bg=D["bg2"], fg=D["ok"], insertbackground=D["fg"],
                             relief="flat", borderwidth=0, font=("Consolas", 9))
        self.i_log.pack(side="left", fill="both", expand=True)
        sb3 = ttk.Scrollbar(self.i_log_frame, command=self.i_log.yview); sb3.pack(side="right", fill="y")
        self.i_log.configure(yscrollcommand=sb3.set)

        ttk.Label(self.root, textvariable=self.status, relief="sunken", anchor="w"
                  ).pack(fill="x", side="bottom")

    # ========================================================
    #  AYARLAR
    # ========================================================
    def _reset_settings(self):
        self.settings = dict(DEFAULT_SETTINGS)
        self.lang.set(DEFAULT_SETTINGS["lang"])
        self.codec_id = DEFAULT_SETTINGS["codec_id"]
        self.container_id = DEFAULT_SETTINGS["container_id"]
        self.audio_codec_id = DEFAULT_SETTINGS["audio_codec_id"]
        self.audio_only.set(DEFAULT_SETTINGS["audio_only"])
        self.preset.set(DEFAULT_SETTINGS["preset"])
        self.crf.set(DEFAULT_SETTINGS["crf"])
        self.resolution.set(DEFAULT_SETTINGS["resolution_tr"])
        self.audio_br.set(DEFAULT_SETTINGS["audio_br"])
        self.a_codec_id = DEFAULT_SETTINGS["a_codec_id"]
        self.a_br.set(DEFAULT_SETTINGS["a_br"])
        self.img_format_id = DEFAULT_SETTINGS["img_format_id"]
        self.img_quality.set(DEFAULT_SETTINGS["img_quality"])
        self._refresh_lists()
        self._refresh_a_lists()
        self._refresh_img_lists()
        self._on_audio_only_toggle()
        self._do_save()
        self.log_msg(self.L("log_settings_reset"))

    # ---------------- Video tab ----------------
    def _on_codec_selected(self, event=None):
        table = CODEC_LABELS.get(self.lang.get(), CODEC_LABELS["tr"])
        cur = self.codec_display.get()
        for cid, label in table.items():
            if label == cur: self.codec_id = cid; break
        self._schedule_save()

    def _on_container_selected(self, event=None):
        table = CONTAINER_LABELS.get(self.lang.get(), CONTAINER_LABELS["tr"])
        cur = self.container_display.get()
        for cid, label in table.items():
            if label == cur: self.container_id = cid; break
        self._schedule_save()

    def _on_audiocodec_selected(self, event=None):
        table = AUDIO_LABELS.get(self.lang.get(), AUDIO_LABELS["tr"])
        cur = self.audio_codec_display.get()
        for cid, label in table.items():
            if label == cur: self.audio_codec_id = cid; break
        self._schedule_save()

    def _on_audio_only_toggle(self):
        if self.audio_only.get():
            for w in (self.cmb_enc, self.cmb_cont, self.cmb_pre, self.spn_crf, self.cmb_res):
                try: w.configure(state="disabled")
                except: pass
            self.cmb_ac.configure(state="readonly")
        else:
            self.cmb_enc.configure(state="readonly")
            self.cmb_cont.configure(state="readonly")
            self.cmb_pre.configure(state="readonly")
            self.spn_crf.configure(state="normal")
            self.cmb_res.configure(state="readonly")
            self.cmb_ac.configure(state="disabled")
        self._schedule_save()

    # ---------------- Ses tab ----------------
    def _on_a_codec_selected(self, event=None):
        table = AUDIO_LABELS.get(self.lang.get(), AUDIO_LABELS["tr"])
        cur = self.a_codec_display.get()
        for cid, label in table.items():
            if label == cur: self.a_codec_id = cid; break
        self._schedule_save()

    def _refresh_a_lists(self):
        lang = self.lang.get()
        at = AUDIO_LABELS.get(lang, AUDIO_LABELS["tr"])
        av = list(at.values())
        self.cmb_acodec.configure(values=av)
        if self.a_codec_id not in at: self.a_codec_id = "mp3"
        self.a_codec_display.set(at.get(self.a_codec_id, av[0]))

    # ---------------- Fotoğraf tab ----------------
    def _on_img_format_selected(self, event=None):
        table = IMAGE_LABELS.get(self.lang.get(), IMAGE_LABELS["tr"])
        cur = self.img_format_display.get()
        for cid, label in table.items():
            if label == cur: self.img_format_id = cid; break
        self._schedule_save()

    def _refresh_img_lists(self):
        lang = self.lang.get()
        it = IMAGE_LABELS.get(lang, IMAGE_LABELS["tr"])
        iv = list(it.values())
        self.cmb_imgfmt.configure(values=iv)
        if self.img_format_id not in it: self.img_format_id = "jpg"
        self.img_format_display.set(it.get(self.img_format_id, iv[0]))

    # ---------------- Dil ----------------
    def _on_lang_combo(self, event=None):
        label = self.lang_display.get()
        m = re.search(r"\(([a-z]{2,5})\)$", label)
        if m: self.lang.set(m.group(1))

    def _set_lang_display(self):
        code = self.lang.get()
        name = LANG_NAMES.get(code, code)
        self.lang_display.set(f"{name} ({code})")

    def _refresh_lists(self):
        lang = self.lang.get()
        ct = CODEC_LABELS.get(lang, CODEC_LABELS["tr"])
        cv = list(ct.values())
        self.cmb_enc.configure(values=cv)
        if self.codec_id not in ct: self.codec_id = "libx264"
        self.codec_display.set(ct.get(self.codec_id, cv[0]))
        ht = CONTAINER_LABELS.get(lang, CONTAINER_LABELS["tr"])
        hv = list(ht.values())
        self.cmb_cont.configure(values=hv)
        if self.container_id not in ht: self.container_id = "mp4"
        self.container_display.set(ht.get(self.container_id, hv[0]))
        at = AUDIO_LABELS.get(lang, AUDIO_LABELS["tr"])
        av = list(at.values())
        self.cmb_ac.configure(values=av)
        if self.audio_codec_id not in at: self.audio_codec_id = "aac"
        self.audio_codec_display.set(at.get(self.audio_codec_id, av[0]))

    def _on_lang_change(self):
        L = self.L
        self._set_lang_display()
        self.lbl_lang.configure(text=L("lang_label"))
        self.btn_reset.configure(text=L("btn_reset"))
        # Sekmeler
        self.nb.tab(self.t1, text=L("tab_conv"))
        self.nb.tab(self.t2, text=L("tab_batch"))
        self.nb.tab(self.t3, text=L("tab_info"))
        self.nb.tab(self.t4, text=L("tab_audio"))
        self.nb.tab(self.t5, text=L("tab_image"))
        # Video tab
        self.f_src.configure(text=L("src_frame"))
        self.f_out.configure(text=L("out_frame"))
        self.f_set.configure(text=L("settings_frame"))
        self.log_frame.configure(text=L("log_frame"))
        self.btn_pick.configure(text=L("btn_pick"))
        self.btn_play.configure(text=L("btn_play"))
        self.btn_out.configure(text=L("btn_pick"))
        self.btn_conv.configure(text=L("btn_convert"))
        self.btn_badd.configure(text=L("btn_batch_add"))
        self.btn_bclr.configure(text=L("btn_batch_clr"))
        self.btn_brun.configure(text=L("btn_batch_run"))
        self.btn_an.configure(text=L("btn_analyze"))
        self.lbl_enc.configure(text=L("lbl_encoder"))
        self.lbl_cont.configure(text=L("lbl_container"))
        self.lbl_pre.configure(text=L("lbl_preset"))
        self.lbl_crf.configure(text=L("lbl_crf"))
        self.lbl_res.configure(text=L("lbl_res"))
        self.lbl_abr.configure(text=L("lbl_abr"))
        self.lbl_ac.configure(text=L("lbl_acodec"))
        self.chk_ao.configure(text=L("chk_audio_only"))
        self.tree.heading("p", text=L("col_file"))
        self.tree.heading("s", text=L("col_status"))
        cur = self.resolution.get()
        new_list, new_val = translate_res(cur, self.lang.get())
        self.cmb_res.configure(values=new_list)
        self.resolution.set(new_val)
        # Ses tab
        self.f_asrc.configure(text=L("audio_src_frame"))
        self.f_aout.configure(text=L("out_frame"))
        self.f_aset.configure(text=L("audio_settings_frame"))
        self.a_log_frame.configure(text=L("log_frame"))
        self.btn_apick.configure(text=L("btn_pick"))
        self.btn_aplay.configure(text=L("btn_play"))
        self.btn_aout.configure(text=L("btn_pick"))
        self.btn_aconv.configure(text=L("btn_audio_convert"))
        self.lbl_acodec.configure(text=L("lbl_audio_codec"))
        self.lbl_abrate.configure(text=L("lbl_abr"))
        # Fotoğraf tab
        self.f_imgsrc.configure(text=L("image_src_frame"))
        self.f_imgout.configure(text=L("out_frame"))
        self.f_imgset.configure(text=L("image_settings_frame"))
        self.i_log_frame.configure(text=L("log_frame"))
        self.btn_imgadd.configure(text=L("btn_img_add_files"))
        self.btn_imgaddf.configure(text=L("btn_img_add_folder"))
        self.btn_imgclr.configure(text=L("btn_img_clear"))
        self.btn_imgout.configure(text=L("btn_pick"))
        self.btn_iconv.configure(text=L("btn_image_convert"))
        self.lbl_imgfmt.configure(text=L("lbl_img_format"))
        self.lbl_imgq.configure(text=L("lbl_img_quality"))
        self.img_tree.heading("f", text=L("col_file"))
        self.img_tree.heading("s", text=L("col_status"))
        self._refresh_lists()
        self._refresh_a_lists()
        self._refresh_img_lists()
        if not self.ffmpeg:
            self.status.set(L("st_downloading"))
        self._schedule_save()

    # ========================================================
    #  LOG
    # ========================================================
    def log_msg(self, s):
        self.log.configure(state="normal")
        self.log.insert("end", s + "\n"); self.log.see("end")
        self.log.configure(state="disabled")

    def a_log_msg(self, s):
        self.a_log.configure(state="normal")
        self.a_log.insert("end", s + "\n"); self.a_log.see("end")
        self.a_log.configure(state="disabled")

    def i_log_msg(self, s):
        self.i_log.configure(state="normal")
        self.i_log.insert("end", s + "\n"); self.i_log.see("end")
        self.i_log.configure(state="disabled")

    # ========================================================
    #  FFMPEG KONTROL
    # ========================================================
    def _check(self):
        p = settings_path()
        self.log_msg(self.L("log_settings_path", p=p))
        if self.ffmpeg and self.ffprobe:
            v = ffmpeg_ver(self.ffmpeg)
            self.log_msg(self.L("log_ffmpeg_ok", path=self.ffmpeg))
            if v: self.log_msg(self.L("log_ver", v=v))
            self.log_msg(self.L("log_ready"))
            self.log_msg(self.L("log_settings_loaded"))
            self.status.set(self.L("st_ready"))
            return
        self.log_msg(self.L("log_ffmpeg_no"))
        self.status.set(self.L("st_downloading"))
        self.btn_conv.configure(state="disabled")
        self.btn_aconv.configure(state="disabled")
        self.btn_iconv.configure(state="disabled")
        self._cancel_event.clear()
        self._dl = DlDialog(self.root, self._cancel_event, self.lang.get(), on_cancel=self._on_cancel)
        threading.Thread(target=self._auto_dl, daemon=True).start()

    def _on_cancel(self):
        self.log_msg(self.L("log_cancelled"))
        self.status.set(self.L("st_cancelled"))

    def _auto_dl(self):
        def lc(m): self.root.after(0, lambda: self.log_msg(m))
        def pc(pct, mb, tot, spd):
            def u():
                if self._dl and self._dl.winfo_exists():
                    self._dl.update_progress(pct, mb, tot, spd)
                self.status.set(self.L("st_dl_progress", p=pct, m=mb, t=tot, s=spd))
                self.pb.configure(value=pct)
            self.root.after(0, u)
        ok, msg = download_ffmpeg(
            log=lc, progress=pc, cancel_event=self._cancel_event,
            log_extracting=self.L("log_extracting"),
            msg_windows_only=self.L("err_windows_only"),
            msg_no_exe=self.L("err_no_exe"),
            msg_unknown=self.L("err_unknown"),
            msg_cancelled=self.L("err_cancelled"))
        def done():
            if self._dl and self._dl.winfo_exists(): self._dl.close_safe()
            self._dl = None
            cancelled = self._cancel_event.is_set()
            if ok:
                self.ffmpeg = find_tool("ffmpeg"); self.ffprobe = find_tool("ffprobe")
                self.log_msg(self.L("log_installed", path=self.ffmpeg))
                self.status.set(self.L("st_ready"))
                self.btn_conv.configure(state="normal")
                self.btn_aconv.configure(state="normal")
                self.btn_iconv.configure(state="normal")
                self.pb.configure(value=0)
                messagebox.showinfo(self.L("mb_done_inst"), self.L("mb_done_txt"))
            elif cancelled:
                self.status.set(self.L("st_cancelled"))
                self.btn_conv.configure(state="normal")
                self.btn_aconv.configure(state="normal")
                self.btn_iconv.configure(state="normal")
                self.pb.configure(value=0)
            else:
                self.log_msg(self.L("log_err", e=msg))
                self.status.set(self.L("st_failed_inst"))
                self.btn_conv.configure(state="normal")
                self.btn_aconv.configure(state="normal")
                self.btn_iconv.configure(state="normal")
                self.pb.configure(value=0)
                messagebox.showerror(self.L("mb_err_title"),
                    self.L("mb_err_body", msg=msg, path=os.path.join(base_dir(), "bin")))
        self.root.after(0, done)

    # ========================================================
    #  DOSYA SEÇME
    # ========================================================
    def pick_file(self):
        p = filedialog.askopenfilename(filetypes=[
            (self.L("filetypes_vid"), "*.mp4 *.mkv *.avi *.mov *.wmv *.webm *.m4v *.3gp *.ogv *.mpg *.mxf *.ts *.flv *.m2ts *.rm *.asf *.f4v"),
            (self.L("filetypes_aud"), "*.mp3 *.m4a *.aac *.flac *.wav *.ogg *.opus *.wma *.ac3 *.eac3 *.dts *.amr *.m3u8 *.m3u"),
            (self.L("filetypes_all"), "*.*")])
        if p:
            self.input_path.set(p)
            self.status.set(self.L("st_selected", n=os.path.basename(p)))
            self.log_msg(self.L("log_sel", p=p))

    def pick_out(self):
        d = filedialog.askdirectory()
        if d:
            self.output_dir.set(d)
            self._schedule_save()

    def play(self):
        p = self.input_path.get().strip().strip('"')
        if not p or not os.path.isfile(p):
            messagebox.showwarning("", self.L("warn_no_vid")); return
        try:
            if os.name == "nt": os.startfile(p)
            elif platform.system() == "Darwin": subprocess.Popen(["open", p])
            else: subprocess.Popen(["xdg-open", p])
        except Exception as e: messagebox.showerror(self.L("err_generic"), str(e))

    def a_pick_file(self):
        p = filedialog.askopenfilename(filetypes=[
            (self.L("filetypes_aud"), "*.mp3 *.m4a *.aac *.flac *.wav *.ogg *.opus *.wma *.ac3 *.eac3 *.dts *.amr *.m3u8 *.m3u"),
            (self.L("filetypes_vid"), "*.mp4 *.mkv *.avi *.mov *.webm *.flv *.ts *.m2ts *.3gp *.3g2"),
            (self.L("filetypes_all"), "*.*")])
        if p:
            self.a_input_path.set(p)
            self.a_log_msg(self.L("log_sel", p=p))

    def a_pick_out(self):
        d = filedialog.askdirectory()
        if d:
            self.a_output_dir.set(d)
            self._schedule_save()

    def a_play(self):
        p = self.a_input_path.get().strip().strip('"')
        if not p or not os.path.isfile(p):
            messagebox.showwarning("", self.L("warn_no_audio")); return
        try:
            if os.name == "nt": os.startfile(p)
            elif platform.system() == "Darwin": subprocess.Popen(["open", p])
            else: subprocess.Popen(["xdg-open", p])
        except Exception as e: messagebox.showerror(self.L("err_generic"), str(e))

    # ---- Fotoğraf dosya işlemleri ----
    def img_add_files(self):
        exts = " ".join("*" + e for e in sorted(ALL_IMAGE_INPUT_EXTS))
        files = filedialog.askopenfilenames(filetypes=[
            (self.L("filetypes_img"), exts),
            (self.L("filetypes_all"), "*.*")])
        if files:
            for f in files:
                self._add_img_file(f)
            self.i_log_msg(self.L("log_img_added", n=len(files)))

    def img_add_folder(self):
        d = filedialog.askdirectory()
        if not d: return
        n = 0
        for name in os.listdir(d):
            full = os.path.join(d, name)
            if os.path.isfile(full) and os.path.splitext(name)[1].lower() in ALL_IMAGE_INPUT_EXTS:
                self._add_img_file(full); n += 1
        if n:
            self.i_log_msg(self.L("log_img_folder", n=n))
        else:
            messagebox.showinfo("", self.L("warn_no_image"))

    def _add_img_file(self, path):
        if path in self.img_files: return
        self.img_files.append(path)
        self.img_tree.insert("", "end", values=(path, self.L("batch_pending")))

    def img_clear(self):
        self.img_files.clear()
        for i in self.img_tree.get_children(): self.img_tree.delete(i)

    def img_pick_out(self):
        d = filedialog.askdirectory()
        if d:
            self.img_output_dir.set(d)
            self._schedule_save()

    # ========================================================
    #  CODEC GETTER
    # ========================================================
    def _current_codec(self): return CODEC_BY_ID.get(self.codec_id, CODECS[0])
    def _current_container(self): return CONTAINER_BY_ID.get(self.container_id, CONTAINERS[0])
    def _current_audio_codec(self): return AUDIO_BY_ID.get(self.audio_codec_id, AUDIO_CODECS[0])
    def _current_image_format(self): return IMAGE_BY_ID.get(self.img_format_id, IMAGE_FORMATS[0])

    # ========================================================
    #  VIDEO KOMUT
    # ========================================================
    def _build_video_args(self, c):
        args = ["-c:v", c["v_codec"]]
        if c.get("preset"): args += ["-preset", self.preset.get()]
        if c.get("crf"): args += ["-crf", self.crf.get()]
        elif c.get("hw"):
            try: q = int(self.crf.get())
            except: q = 23
            if c["hw"] == "nvenc":
                args += ["-rc","vbr","-cq",str(q),"-b:v","0"]
            elif c["hw"] == "qsv":
                args += ["-global_quality", str(q), "-look_ahead","1"]
            elif c["hw"] == "amf":
                args += ["-rc","cqp","-qp_i",str(q),"-qp_p",str(q)]
        elif c.get("qscale"):
            try: crf = int(self.crf.get())
            except: crf = 23
            q = max(2, min(31, int(2 + (crf / 51.0) * 29)))
            args += ["-q:v", str(q)]
        elif c.get("prores_hq"): args += ["-profile:v","3"]
        elif c.get("prores_422"): args += ["-profile:v","2"]
        elif c.get("dnxhd"): args += ["-b:v","36M"]
        return args

    def _vf_args(self, c, h):
        if not h: return []
        h = int(h)
        if h < 16: return ["-vf", f"scale={h}:{h}"]
        return ["-vf", f"scale=-2:{h}"]

    def _resolve_audio_codec(self, container_ext, desired):
        default = CONTAINER_AUDIO.get(container_ext, "aac")
        if default is None: return None, None
        allowed = {
            ".mp4":  {"aac","libmp3lame","ac3","eac3","alac","libopus","libvorbis"},
            ".m4v":  {"aac","libmp3lame","ac3","eac3","alac"},
            ".mov":  {"aac","libmp3lame","ac3","eac3","alac","pcm_s16le"},
            ".mkv":  {"aac","libmp3lame","libopus","libvorbis","flac","ac3","eac3","dca","pcm_s16le","wmav2"},
            ".webm": {"libopus","libvorbis"},
            ".ogv":  {"libvorbis","libopus","flac"},
            ".avi":  {"libmp3lame","aac","ac3","pcm_s16le"},
            ".wmv":  {"wmav2"}, ".asf": {"wmav2"},
            ".flv":  {"aac","libmp3lame"}, ".f4v": {"aac"},
            ".mpg":  {"mp2","ac3"}, ".mpeg": {"mp2","ac3"},
            ".ts":   {"aac","ac3","mp2"}, ".m2ts": {"aac","ac3"},
            ".3gp":  {"aac","libopencore_amrnb"}, ".3g2": {"aac","libopencore_amrnb"},
            ".mxf":  {"pcm_s16le"}, ".nut": {"aac","libmp3lame","libvorbis","flac","pcm_s16le"},
            ".rm":   {"ac3"}, ".dv": {"pcm_s16le"},
        }
        ok = allowed.get(container_ext, {"aac"})
        if desired in ok: return desired, None
        return default, desired

    def _build_cmd(self, src, dst_guess):
        c = self._current_codec()
        cont = self._current_container()
        h_str = RES_MAP.get(self.resolution.get())
        h = int(h_str) if h_str else None
        if h is not None and h < c.get("min_h", 1) and not self.audio_only.get():
            self.root.after(0, lambda: self.log_msg(
                self.L("autofallback", codec=c["v_codec"], h=h)))
            c = CODEC_BY_ID["mpeg4"]
        base, _ = os.path.splitext(dst_guess)
        ext = cont["ext"]; dst = base + ext

        if self.audio_only.get():
            ac = self._current_audio_codec()
            return self._build_audio_cmd(src, dst_guess, ac, self.audio_br.get())

        v_args = self._build_video_args(c)
        vf = self._vf_args(c, h)
        resolved, fell_back = self._resolve_audio_codec(ext, "aac")
        if fell_back:
            self.root.after(0, lambda e=ext, a=fell_back, n=resolved:
                self.log_msg(self.L("aud_fallback", ext=e, ac=a, nac=n)))
        cmd = [self.ffmpeg, "-y", "-hide_banner", "-i", src, *v_args, *vf]
        if resolved: cmd += ["-c:a", resolved, "-b:a", self.audio_br.get()]
        else: cmd += ["-an"]
        if ext in (".mp4", ".m4v", ".mov", ".f4v"):
            cmd += ["-movflags", "+faststart"]
        cmd += [dst]
        return cmd, dst

    # ========================================================
    #  SES KOMUT
    # ========================================================
    def _build_audio_cmd(self, src, dst_guess, ac, bitrate):
        base, _ = os.path.splitext(dst_guess)
        ext = ac["ext"]
        dst = base + ext
        cmd = [self.ffmpeg, "-y", "-hide_banner", "-i", src, "-vn",
               "-c:a", ac["a_codec"]]
        if ac["a_codec"] not in LOSSLESS_A_CODECS:
            cmd += ["-b:a", bitrate]
        if ac.get("hls"):
            cmd += ["-f", "hls", "-hls_time", "10", "-hls_list_size", "0",
                    "-hls_segment_filename", base + "_%03d.ts"]
        elif ac.get("fmt"):
            cmd += ["-f", ac["fmt"]]
        cmd += [dst]
        return cmd, dst

    # ========================================================
    #  FFMPEG ÇALIŞTIRMA
    # ========================================================
    def _run_ffmpeg(self, cmd, dur, on_done):
        try:
            p = subprocess.Popen(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                                 universal_newlines=True, encoding="utf-8", errors="ignore")
            while True:
                line = p.stderr.readline()
                if not line and p.poll() is not None: break
                if line and dur > 0:
                    m = re.search(r"time=(\d+):(\d+):([\d.]+)", line)
                    if m:
                        hh, mn, s = map(float, m.groups())
                        pct = min(int((hh * 3600 + mn * 60 + s) / dur * 100), 100)
                        self.root.after(0, lambda x=pct: self._upd(x))
            ok = p.poll() == 0
            self.root.after(0, lambda: on_done(ok))
        except Exception as e:
            self.root.after(0, lambda: self.log_msg(self.L("log_err", e=e)))
            self.root.after(0, lambda: on_done(False))

    def _run_ffmpeg_a(self, cmd, dur, on_done):
        try:
            p = subprocess.Popen(cmd, stderr=subprocess.PIPE, stdout=subprocess.PIPE,
                                 universal_newlines=True, encoding="utf-8", errors="ignore")
            while True:
                line = p.stderr.readline()
                if not line and p.poll() is not None: break
                if line and dur > 0:
                    m = re.search(r"time=(\d+):(\d+):([\d.]+)", line)
                    if m:
                        hh, mn, s = map(float, m.groups())
                        pct = min(int((hh * 3600 + mn * 60 + s) / dur * 100), 100)
                        self.root.after(0, lambda x=pct: self._upd_a(x))
            ok = p.poll() == 0
            self.root.after(0, lambda: on_done(ok))
        except Exception as e:
            self.root.after(0, lambda: self.a_log_msg(self.L("log_err", e=e)))
            self.root.after(0, lambda: on_done(False))

    def _get_duration(self, src):
        if not self.ffprobe: return 0
        try:
            r = subprocess.run([self.ffprobe, "-v", "error", "-show_entries",
                "format=duration", "-of", "default=noprint_wrappers=1:nokey=1", src],
                capture_output=True, text=True, timeout=5)
            return float(r.stdout.strip())
        except Exception: return 0

    # ========================================================
    #  VİDEO
    # ========================================================
    def start(self):
        if self.is_converting: return
        if not self.ffmpeg:
            messagebox.showerror(self.L("err_generic"), self.L("err_ffmpeg")); return
        p = self.input_path.get().strip().strip('"')
        if not p or not os.path.isfile(p):
            messagebox.showwarning("", self.L("warn_no_src")); return
        out = self.output_dir.get().strip(); os.makedirs(out, exist_ok=True)
        n = os.path.splitext(os.path.basename(p))[0]
        dst_guess = os.path.join(out, n + "_QuickConventer.mp4")
        self.is_converting = True; self.btn_conv.configure(state="disabled")
        threading.Thread(target=self._convert, args=(p, dst_guess), daemon=True).start()

    def _convert(self, src, dst_guess):
        dur = self._get_duration(src)
        try: cmd, dst = self._build_cmd(src, dst_guess)
        except Exception as e:
            self.root.after(0, lambda: self.log_msg(self.L("log_err", e=e)))
            self.root.after(0, lambda: self._on_convert_done(False, dst_guess))
            return
        self.root.after(0, lambda: self.log_msg(self.L("log_cmd", c=" ".join(cmd))))
        self.root.after(0, lambda: self.status.set(self.L("st_converting")))
        self._run_ffmpeg(cmd, dur, lambda ok: self._on_convert_done(ok, dst))

    def _on_convert_done(self, ok, dst):
        self.is_converting = False; self.btn_conv.configure(state="normal")
        if ok:
            self.pb.configure(value=100); self.pl.configure(text="%100")
            self.status.set(self.L("st_done")); self.log_msg(self.L("log_ok_out", p=dst))
            messagebox.showinfo(self.L("info_ok_title"), self.L("info_ok_body", p=dst))
        else:
            self.status.set(self.L("st_failed"))
            messagebox.showerror(self.L("info_err_title"), self.L("info_err_body"))

    def _upd(self, pct):
        self.pb.configure(value=pct); self.pl.configure(text=f"%{pct}")
        self.status.set(self.L("st_converting2", p=pct))

    # ========================================================
    #  SES
    # ========================================================
    def start_audio(self):
        if self.is_a_converting: return
        if not self.ffmpeg:
            messagebox.showerror(self.L("err_generic"), self.L("err_ffmpeg")); return
        p = self.a_input_path.get().strip().strip('"')
        if not p or not os.path.isfile(p):
            messagebox.showwarning("", self.L("warn_no_audio")); return
        out = self.a_output_dir.get().strip(); os.makedirs(out, exist_ok=True)
        ac = AUDIO_BY_ID.get(self.a_codec_id, AUDIO_CODECS[0])
        n = os.path.splitext(os.path.basename(p))[0]
        dst_guess = os.path.join(out, n + "_Audio" + ac["ext"])
        self.is_a_converting = True; self.btn_aconv.configure(state="disabled")
        threading.Thread(target=self._convert_audio, args=(p, dst_guess, ac), daemon=True).start()

    def _convert_audio(self, src, dst_guess, ac):
        dur = self._get_duration(src)
        try:
            cmd, dst = self._build_audio_cmd(src, dst_guess, ac, self.a_br.get())
        except Exception as e:
            self.root.after(0, lambda: self.a_log_msg(self.L("log_err", e=e)))
            self.root.after(0, lambda: self._on_audio_done(False, dst_guess))
            return
        self.root.after(0, lambda: self.a_log_msg(self.L("log_cmd", c=" ".join(cmd))))
        self._run_ffmpeg_a(cmd, dur, lambda ok: self._on_audio_done(ok, dst))

    def _on_audio_done(self, ok, dst):
        self.is_a_converting = False; self.btn_aconv.configure(state="normal")
        if ok:
            self.a_pb.configure(value=100); self.a_pl.configure(text="%100")
            self.a_log_msg(self.L("log_ok_out", p=dst))
            messagebox.showinfo(self.L("info_ok_title"), self.L("info_audio_ok_body", p=dst))
        else:
            messagebox.showerror(self.L("info_err_title"), self.L("info_audio_err_body"))

    def _upd_a(self, pct):
        self.a_pb.configure(value=pct); self.a_pl.configure(text=f"%{pct}")

    # ========================================================
    #  FOTOĞRAF DÖNÜŞTÜRME
    # ========================================================
    def start_image(self):
        if self.is_img_converting: return
        if not self.img_files:
            messagebox.showwarning("", self.L("warn_no_image")); return
        if not self.ffmpeg and not has_pillow():
            messagebox.showerror(self.L("err_generic"), self.L("err_ffmpeg")); return
        out = self.img_output_dir.get().strip(); os.makedirs(out, exist_ok=True)
        self.is_img_converting = True
        self.btn_iconv.configure(state="disabled")
        self.i_pb.configure(value=0); self.i_pl.configure(text="%0")
        files = list(self.img_files)
        fmt = self._current_image_format()
        try: q = int(self.img_quality.get())
        except: q = 90
        q = max(1, min(100, q))
        threading.Thread(target=self._image_worker,
                         args=(files, out, fmt, q), daemon=True).start()

    def _image_worker(self, files, out_dir, fmt, quality):
        total = len(files)
        ok_count = 0
        fail_count = 0
        items = list(self.img_tree.get_children())

        # RAW gerekiyorsa Pillow + rawpy kontrol et
        need_raw = any(os.path.splitext(f)[1].lower() in RAW_INPUT_EXTS for f in files)
        if need_raw:
            if not has_pillow():
                self.root.after(0, lambda: self.i_log_msg(self.L("log_img_installing")))
                if _pip_install("Pillow", lambda m: self.root.after(0, lambda: self.i_log_msg(m))):
                    self.root.after(0, lambda: self.i_log_msg(self.L("log_img_installed")))
                else:
                    self.root.after(0, lambda: self.i_log_msg(self.L("log_img_install_fail", e="pip")))
            if not has_rawpy():
                self.root.after(0, lambda: self.i_log_msg(self.L("log_img_rawpy_installing")))
                if _pip_install("rawpy", lambda m: self.root.after(0, lambda: self.i_log_msg(m))):
                    self.root.after(0, lambda: self.i_log_msg(self.L("log_img_rawpy_installed")))
                else:
                    self.root.after(0, lambda: self.i_log_msg(self.L("log_img_rawpy_fail", e="pip")))

        for idx, src in enumerate(files):
            # treeview satırı bul
            tree_item = None
            for it in items:
                vals = self.img_tree.item(it, "values")
                if vals and vals[0] == src:
                    tree_item = it; break
            if tree_item:
                self.root.after(0, lambda i=tree_item, s=src: self.img_tree.item(i, values=(s, self.L("batch_run"))))

            success, result = self._convert_one_image(src, out_dir, fmt, quality)
            if success:
                ok_count += 1
                if tree_item:
                    self.root.after(0, lambda i=tree_item, s=src: self.img_tree.item(i, values=(s, self.L("img_done"))))
                self.root.after(0, lambda p=result: self.i_log_msg(self.L("log_ok_out", p=p)))
            else:
                fail_count += 1
                if tree_item:
                    self.root.after(0, lambda i=tree_item, s=src: self.img_tree.item(i, values=(s, self.L("img_err"))))
                self.root.after(0, lambda e=result, s=src: self.i_log_msg(f"[!] {os.path.basename(s)}: {e}"))

            pct = int((idx + 1) / total * 100)
            self.root.after(0, lambda p=pct: self._upd_i(p))

        self.root.after(0, lambda: self._on_image_done(ok_count, fail_count, out_dir))

    def _convert_one_image(self, src, out_dir, fmt, quality):
        """Tek fotoğrafı dönüştür. (başarı, sonuç_yolu_veya_hata)"""
        base = os.path.splitext(os.path.basename(src))[0]
        dst = os.path.join(out_dir, base + fmt["ext"])
        if os.path.abspath(src) == os.path.abspath(dst):
            dst = os.path.join(out_dir, base + "_conv" + fmt["ext"])

        ext = os.path.splitext(src)[1].lower()

        # RAW input → Pillow + rawpy
        if ext in RAW_INPUT_EXTS:
            return self._convert_raw_with_pillow(src, dst, fmt, quality)

        # Standart → FFmpeg dene
        if self.ffmpeg and fmt.get("ffmpeg"):
            try:
                cmd = self._build_image_cmd(src, dst, fmt, quality)
                r = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
                if r.returncode == 0 and os.path.isfile(dst) and os.path.getsize(dst) > 0:
                    return True, dst
            except Exception:
                pass

        # FFmpeg başarısız → Pillow fallback
        if has_pillow():
            return self._convert_with_pillow(src, dst, fmt, quality)

        return False, "FFmpeg failed and Pillow not available"

    def _build_image_cmd(self, src, dst, fmt, quality):
        cmd = [self.ffmpeg, "-y", "-hide_banner", "-i", src]
        codec = fmt.get("ffmpeg")
        if codec == "mjpeg":
            qv = max(1, min(31, round(31 - quality * 0.29)))
            cmd += ["-c:v", "mjpeg", "-q:v", str(qv)]
        elif codec == "libwebp":
            cmd += ["-c:v", "libwebp", "-quality", str(quality)]
        elif codec == "libaom-av1":
            # AVIF
            cmd += ["-c:v", "libaom-av1", "-still-picture", "1",
                    "-cpu-used", "6", "-crf", str(max(10, 63 - int(quality * 0.5)))]
        elif codec:
            cmd += ["-c:v", codec]
        cmd += ["-frames:v", "1", dst]
        return cmd

    def _convert_with_pillow(self, src, dst, fmt, quality):
        try:
            from PIL import Image
        except ImportError:
            return False, "Pillow yok"
        try:
            img = Image.open(src)
            pillow_fmt = fmt.get("pillow") or "PNG"
            # JPEG'de RGBA → RGB
            if pillow_fmt == "JPEG" and img.mode in ("RGBA", "LA", "P"):
                bg = Image.new("RGB", img.size, (255, 255, 255))
                if img.mode == "RGBA":
                    bg.paste(img, mask=img.split()[-1])
                elif img.mode == "P":
                    img2 = img.convert("RGBA")
                    bg.paste(img2, mask=img2.split()[-1])
                else:
                    bg.paste(img)
                img = bg
            kwargs = {}
            if pillow_fmt == "JPEG":
                kwargs = {"quality": max(1, min(95, quality)), "optimize": True}
            elif pillow_fmt == "WEBP":
                kwargs = {"quality": quality}
            elif pillow_fmt == "PNG":
                kwargs = {"optimize": True}
            elif pillow_fmt == "GIF":
                kwargs = {"optimize": True}
            img.save(dst, format=pillow_fmt, **kwargs)
            return True, dst
        except Exception as e:
            return False, str(e)

    def _convert_raw_with_pillow(self, src, dst, fmt, quality):
        try:
            import rawpy
        except ImportError:
            return False, "rawpy yok"
        try:
            from PIL import Image
        except ImportError:
            return False, "Pillow yok"
        try:
            with rawpy.imread(src) as raw:
                rgb = raw.postprocess()
            img = Image.fromarray(rgb)
            pillow_fmt = fmt.get("pillow") or "PNG"
            kwargs = {}
            if pillow_fmt == "JPEG":
                kwargs = {"quality": max(1, min(95, quality)), "optimize": True}
            elif pillow_fmt == "WEBP":
                kwargs = {"quality": quality}
            elif pillow_fmt == "PNG":
                kwargs = {"optimize": True}
            img.save(dst, format=pillow_fmt, **kwargs)
            return True, dst
        except Exception as e:
            return False, f"RAW hatası: {e}"

    def _on_image_done(self, ok, fail, out_dir):
        self.is_img_converting = False
        self.btn_iconv.configure(state="normal")
        self.i_pb.configure(value=100); self.i_pl.configure(text="%100")
        if fail == 0:
            messagebox.showinfo(self.L("info_ok_title"),
                self.L("info_image_ok_body", p=f"{out_dir}  ({ok} dosya)"))
        else:
            messagebox.showwarning(self.L("info_err_title"),
                self.L("info_image_err_body") + f"\n\nOK: {ok}  |  Fail: {fail}")

    def _upd_i(self, pct):
        self.i_pb.configure(value=pct); self.i_pl.configure(text=f"%{pct}")

    # ========================================================
    #  TOPLU İŞLEM
    # ========================================================
    def batch_add(self):
        for f in filedialog.askopenfilenames(filetypes=[
                (self.L("filetypes_vid"), "*.mp4 *.mkv *.avi *.mov *.wmv *.webm *.m4v *.3gp *.ogv *.mpg *.mxf *.ts *.flv *.m2ts *.rm *.asf *.f4v"),
                (self.L("filetypes_aud"), "*.mp3 *.m4a *.aac *.flac *.wav *.ogg *.opus *.wma *.ac3 *.eac3 *.dts *.amr")]):
            self.tree.insert("", "end", values=(f, self.L("batch_pending")))

    def batch_clear(self):
        for i in self.tree.get_children(): self.tree.delete(i)

    def batch_start(self):
        if not self.ffmpeg:
            messagebox.showerror(self.L("err_generic"), self.L("err_ffmpeg")); return
        items = self.tree.get_children()
        if not items:
            messagebox.showwarning("", self.L("warn_empty")); return
        threading.Thread(target=self._batch_run, args=(items,), daemon=True).start()

    def _batch_run(self, items):
        out = self.output_dir.get().strip(); os.makedirs(out, exist_ok=True)
        for it in items:
            src = self.tree.item(it, "values")[0]
            n = os.path.splitext(os.path.basename(src))[0]
            dst_guess = os.path.join(out, n + "_Batch.mp4")
            self.root.after(0, lambda i=it, s=src: self.tree.item(i, values=(s, self.L("batch_run"))))
            try:
                cmd, dst = self._build_cmd(src, dst_guess)
                r = subprocess.run(cmd, capture_output=True, text=True)
                st = self.L("batch_done") if r.returncode == 0 else self.L("batch_err")
            except Exception:
                st = self.L("batch_err")
            self.root.after(0, lambda i=it, s=src, x=st: self.tree.item(i, values=(s, x)))
        self.root.after(0, lambda: messagebox.showinfo(self.L("batch_ok_title"), self.L("batch_ok_body")))

    # ========================================================
    #  BİLGİ
    # ========================================================
    def info(self):
        p = self.input_path.get().strip().strip('"')
        if not p or not os.path.isfile(p):
            messagebox.showwarning("", self.L("warn_no_vid")); return
        if not self.ffprobe:
            messagebox.showerror(self.L("err_generic"), self.L("err_ffprobe")); return
        try:
            r = subprocess.run([self.ffprobe, "-v", "error", "-show_format", "-show_streams", p],
                               capture_output=True, text=True, timeout=10)
            self.itxt.delete("1.0", "end")
            self.itxt.insert("end", r.stdout or r.stderr or "")
        except Exception as e: messagebox.showerror(self.L("err_generic"), str(e))


def main():
    root = tk.Tk()
    apply_theme(root)
    App(root)
    root.mainloop()


if __name__ == "__main__":
    main()