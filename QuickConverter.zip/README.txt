everything is auto
select a file
select a format(mp3/wav and like)
and press the convert button
its finished
