# QuickConventer

A multilingual (TR/EN), dark-themed video converter powered by FFmpeg.

![Python](https://img.shields.io/badge/Python-3.8%2B-blue)
![Platform](https://img.shields.io/badge/Platform-Windows%20%7C%20Linux%20%7C%20macOS-lightgrey)
![License](https://img.shields.io/badge/License-MIT-green)
![FFmpeg](https://img.shields.io/badge/FFmpeg-required-orange)

## ✨ Features

- 🎬 **All popular codecs** — H.264, H.265, VP8, VP9, AV1, MPEG-4, ProRes, DNxHD, MJPEG, FFV1, HuffYUV...
- 🖥️ **Hardware acceleration** — NVENC (NVIDIA), QSV (Intel), AMF (AMD)
- 📐 **Resolution down to 1p** — from 8K all the way to 1×1 pixel
- 📦 **All common containers** — MP4, MKV, WebM, MOV, AVI, WMV, FLV, GIF, MXF, 3GP...
- 🔊 **Audio extraction** — MP3, AAC, FLAC, WAV, Opus, ALAC, AC3, DTS...
- 🌍 **Turkish + English** — instant switch
- 💾 **Persistent settings** — close & reopen, everything is remembered
- 🎨 **Dark theme** — VS Code style
- 🚀 **Auto-downloads FFmpeg** — no manual installation required
- 📊 **Live progress** + cancel button
- 📋 **Batch queue** — convert multiple files in a row

## 🚀 Installation

### Requirements
- **Python 3.8+**
- **FFmpeg** — the app auto-downloads it on Windows. On Linux/macOS install it manually:

```bash
# Ubuntu / Debian
sudo apt install ffmpeg

# Fedora
sudo dnf install ffmpeg

# macOS
brew install ffmpeg